<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;
foreach ( array( 'audit', 'requests', 'orders', 'customers' ) as $t ) {
	$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'rfai_' . $t ); // phpcs:ignore WordPress.DB
}
foreach ( array( 'rfai_settings', 'rfai_seeded', 'rfai_db_version', 'rfai_portal_page' ) as $o ) {
	delete_option( $o );
}
