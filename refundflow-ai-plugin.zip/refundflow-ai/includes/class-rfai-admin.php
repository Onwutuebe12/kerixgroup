<?php
defined( 'ABSPATH' ) || exit;

class RFAI_Admin {

	private static $hook = '';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'admin_body_class', array( __CLASS__, 'body_class' ) );
	}

	public static function menu() {
		self::$hook = add_menu_page(
			'RefundFlow AI',
			'RefundFlow AI',
			apply_filters( 'rfai_capability', 'manage_options' ),
			'refundflow-ai',
			array( __CLASS__, 'render' ),
			'dashicons-money-alt',
			58
		);
	}

	private static function is_screen() {
		return isset( $_GET['page'] ) && 'refundflow-ai' === sanitize_key( wp_unslash( $_GET['page'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
	}

	public static function body_class( $classes ) {
		return self::is_screen() ? $classes . ' rfai-admin' : $classes;
	}

	public static function assets( $hook ) {
		if ( $hook !== self::$hook ) {
			return;
		}
		$views = array( 'overview', 'requests', 'customers', 'orders', 'policy', 'audit', 'settings' );
		$view  = isset( $_GET['view'] ) ? sanitize_key( wp_unslash( $_GET['view'] ) ) : 'overview'; // phpcs:ignore WordPress.Security.NonceVerification
		$user  = wp_get_current_user();

		wp_enqueue_style( 'rfai-admin', RFAI_URL . 'assets/admin.css', array(), RFAI_VERSION );
		wp_enqueue_script( 'rfai-admin', RFAI_URL . 'assets/admin.js', array(), RFAI_VERSION, true );
		wp_localize_script(
			'rfai-admin',
			'RFAI',
			array(
				'root'   => preg_replace( '#^https?://[^/]+#i', '', esc_url_raw( rest_url( RFAI_REST::NS . '/' ) ) ),
				'nonce'  => wp_create_nonce( 'wp_rest' ),
				'portal' => RFAI_DB::portal_url(),
				'user'   => $user->display_name,
				'view'   => in_array( $view, $views, true ) ? $view : 'overview',
				'page'   => admin_url( 'admin.php?page=refundflow-ai' ),
			)
		);
	}

	public static function render() {
		echo '<div id="rfai-app" class="rfai-app"><noscript>RefundFlow AI needs JavaScript to run.</noscript></div>';
	}
}
