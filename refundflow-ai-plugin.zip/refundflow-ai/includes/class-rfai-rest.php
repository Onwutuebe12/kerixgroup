<?php
defined( 'ABSPATH' ) || exit;

class RFAI_REST {

	const NS = 'rfai/v1';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function can() {
		return current_user_can( apply_filters( 'rfai_capability', 'manage_options' ) );
	}

	public static function routes() {
		$admin = array( 'permission_callback' => array( __CLASS__, 'can' ) );
		$pub   = array( 'permission_callback' => '__return_true' );

		register_rest_route( self::NS, '/submit', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'submit' ) ) + $pub );
		register_rest_route( self::NS, '/lookup', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'lookup' ) ) + $pub );
		register_rest_route( self::NS, '/chat', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'chat' ) ) + $pub );

		register_rest_route( self::NS, '/stats', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'stats' ) ) + $admin );
		register_rest_route( self::NS, '/requests', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'requests' ) ) + $admin );
		register_rest_route( self::NS, '/requests/(?P<id>\d+)', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'request' ) ) + $admin );
		register_rest_route( self::NS, '/requests/(?P<id>\d+)/resolve', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'resolve' ) ) + $admin );
		register_rest_route( self::NS, '/customers', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'customers' ) ) + $admin );
		register_rest_route( self::NS, '/orders', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'orders' ) ) + $admin );
		register_rest_route( self::NS, '/policy', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'policy' ) ) + $admin );
		register_rest_route( self::NS, '/settings', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'get_settings' ) ) + $admin );
		register_rest_route( self::NS, '/settings', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'save_settings' ) ) + $admin );
		register_rest_route( self::NS, '/settings/test', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'test_ai' ) ) + $admin );
		register_rest_route( self::NS, '/reseed', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'reseed' ) ) + $admin );
	}

	/* --------------------------------------------------------------- public */

	private static function limited() {
		$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '0';
		$key = 'rfai_rl_' . md5( $ip );
		$n   = (int) get_transient( $key );
		$lim = max( 1, (int) RFAI_DB::settings()['rate_limit'] );
		if ( $n >= $lim ) {
			return true;
		}
		set_transient( $key, $n + 1, HOUR_IN_SECONDS );
		return false;
	}

	private static function fail( $code, $msg, $status ) {
		return new WP_REST_Response( array( 'ok' => false, 'code' => $code, 'message' => $msg ), $status );
	}

	public static function submit( WP_REST_Request $r ) {
		if ( $r->get_param( 'website' ) ) { // Honeypot.
			return self::fail( 'rejected', 'Request could not be processed.', 400 );
		}
		if ( self::limited() ) {
			return self::fail( 'rate_limited', 'You’ve sent a lot of requests. Please try again in a little while.', 429 );
		}
		$att = $r->get_param( 'attachments' );
		$out = RFAI_Engine::process(
			array(
				'order_number' => (string) $r->get_param( 'order_number' ),
				'email'        => (string) $r->get_param( 'email' ),
				'message'      => (string) $r->get_param( 'message' ),
				'attachments'  => is_array( $att ) ? count( $att ) : 0,
			)
		);
		if ( empty( $out['ok'] ) ) {
			return self::fail( $out['code'], $out['message'], $out['status'] );
		}
		// Public payload only: internal reasoning and flags stay in the admin dashboard.
		$pub = array(
			'ok'           => true,
			'reference'    => $out['reference'],
			'decision'     => $out['decision'],
			'reply'        => $out['reply'],
			'order_number' => $out['order_number'],
			'item'         => $out['item'],
			'duplicate'    => ! empty( $out['duplicate'] ),
		);
		if ( 'approved' === $out['decision'] && isset( $out['amount'] ) ) {
			$pub['amount'] = $out['amount'];
		}
		return new WP_REST_Response( $pub, 200 );
	}

	public static function chat( WP_REST_Request $r ) {
		if ( self::limited() ) {
			return self::fail( 'rate_limited', 'You’ve sent a lot of messages. Please try again in a little while.', 429 );
		}
		$out = RFAI_Engine::answer_followup( (string) $r->get_param( 'reference' ), (string) $r->get_param( 'email' ), (string) $r->get_param( 'question' ) );
		if ( empty( $out['ok'] ) ) {
			return self::fail( $out['code'], $out['message'], $out['status'] );
		}
		return new WP_REST_Response( $out, 200 );
	}

	public static function lookup( WP_REST_Request $r ) {
		if ( self::limited() ) {
			return self::fail( 'rate_limited', 'You’ve sent a lot of requests. Please try again in a little while.', 429 );
		}
		$out = RFAI_Engine::lookup( array( 'order_number' => (string) $r->get_param( 'order_number' ), 'email' => (string) $r->get_param( 'email' ) ) );
		if ( empty( $out['ok'] ) ) {
			return self::fail( $out['code'], $out['message'], $out['status'] );
		}
		return new WP_REST_Response( $out, 200 );
	}

	/* ---------------------------------------------------------------- admin */

	private static function iso( $mysql ) {
		return $mysql ? gmdate( 'Y-m-d\TH:i:s\Z', strtotime( $mysql . ' UTC' ) ) : null;
	}

	private static function fmt( $r ) {
		$flags = json_decode( (string) $r->flags, true );
		$by    = '';
		if ( $r->resolved_by ) {
			$u  = get_userdata( (int) $r->resolved_by );
			$by = $u ? $u->display_name : '';
		}
		return array(
			'id'             => (int) $r->id,
			'reference'      => $r->reference,
			'customer'       => array( 'name' => $r->customer_name, 'email' => $r->customer_email ),
			'order_number'   => $r->order_number,
			'item'           => $r->item,
			'amount'         => (float) $r->amount,
			'category'       => $r->category,
			'decision'       => $r->decision,
			'initial'        => $r->initial_decision,
			'rule_id'        => $r->rule_id,
			'rule_label'     => RFAI_Policy::label( $r->rule_id ),
			'reason'         => $r->reason,
			'reply'          => $r->customer_reply,
			'message'        => $r->message,
			'ai_used'        => (bool) $r->ai_used,
			'ai_confidence'  => (float) $r->ai_confidence,
			'ai_summary'     => $r->ai_summary,
			'flags'          => is_array( $flags ) ? $flags : array(),
			'policy_version' => $r->policy_version,
			'attachments'    => (int) $r->attachments,
			'human_reviewed' => (bool) $r->human_reviewed,
			'resolved_by'    => $by,
			'resolved_note'  => $r->resolved_note,
			'resolved_at'    => self::iso( $r->resolved_at ),
			'created_at'     => self::iso( $r->created_at ),
		);
	}

	private static function pct( $cur, $prev ) {
		$cur  = (int) $cur;
		$prev = (int) $prev;
		if ( 0 === $prev ) {
			return $cur > 0 ? null : 0;
		}
		return (int) round( ( $cur - $prev ) / $prev * 100 );
	}

	public static function stats() {
		global $wpdb;
		$rt  = RFAI_DB::t( 'requests' );
		$now = time();
		$w1  = gmdate( 'Y-m-d H:i:s', $now - 7 * DAY_IN_SECONDS );
		$w0  = gmdate( 'Y-m-d H:i:s', $now - 14 * DAY_IN_SECONDS );

		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT decision, COUNT(*) total, SUM(created_at >= %s) cur, SUM(created_at >= %s AND created_at < %s) prev FROM $rt GROUP BY decision", $w1, $w0, $w1 ), ARRAY_A );
		$agg  = array( 'total' => array( 0, 0, 0 ) );
		foreach ( $rows as $r ) {
			$agg[ $r['decision'] ] = array( (int) $r['total'], (int) $r['cur'], (int) $r['prev'] );
			$agg['total'][0]      += (int) $r['total'];
			$agg['total'][1]      += (int) $r['cur'];
			$agg['total'][2]      += (int) $r['prev'];
		}
		$out = array();
		foreach ( array( 'total', 'approved', 'denied', 'escalated' ) as $k ) {
			$a         = isset( $agg[ $k ] ) ? $agg[ $k ] : array( 0, 0, 0 );
			$out[ $k ] = array( 'value' => $a[0], 'delta' => self::pct( $a[1], $a[2] ) );
		}

		// Insight line.
		$dmg1 = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $rt WHERE category='damaged' AND created_at >= %s", $w1 ) );
		$dmg0 = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $rt WHERE category='damaged' AND created_at >= %s AND created_at < %s", $w0, $w1 ) );
		if ( $dmg0 > 0 ) {
			$p    = self::pct( $dmg1, $dmg0 );
			$line = 'Damaged-item requests are ' . ( $p >= 0 ? 'up ' : 'down ' ) . abs( $p ) . '% this week.';
		} elseif ( $dmg1 > 0 ) {
			$line = $dmg1 . ' damaged-item request' . ( 1 === $dmg1 ? '' : 's' ) . ' this week.';
		} else {
			$line = 'No damaged-item requests this week.';
		}
		$top = $wpdb->get_row( "SELECT rule_id, COUNT(*) n FROM $rt WHERE initial_decision='escalated' GROUP BY rule_id ORDER BY n DESC LIMIT 1" );
		if ( $top ) {
			$hv   = number_format( (float) RFAI_DB::settings()['high_value'], 0 );
			$why  = array(
				'high_value'   => "the \${$hv} review threshold",
				'suspicious'   => 'suspicious or conflicting signals',
				'needs_review' => 'claims that need human judgment',
			);
			$line .= ' Most escalations are due to ' . ( isset( $why[ $top->rule_id ] ) ? $why[ $top->rule_id ] : 'policy review rules' ) . '.';
		}
		$out['insight'] = $line;
		$out['pending'] = $out['escalated']['value'];
		return $out;
	}

	public static function requests( WP_REST_Request $r ) {
		global $wpdb;
		$w = array( '1=1' );
		$a = array();
		$st = sanitize_key( (string) $r->get_param( 'status' ) );
		if ( in_array( $st, array( 'approved', 'denied', 'escalated' ), true ) ) {
			$w[] = 'r.decision = %s';
			$a[] = $st;
		}
		$cat = sanitize_key( (string) $r->get_param( 'reason' ) );
		if ( in_array( $cat, RFAI_Gemini::CATS, true ) ) {
			$w[] = 'r.category = %s';
			$a[] = $cat;
		}
		$days = array( '7d' => 7, '30d' => 30 );
		$rg   = (string) $r->get_param( 'range' );
		if ( isset( $days[ $rg ] ) ) {
			$w[] = 'r.created_at >= %s';
			$a[] = gmdate( 'Y-m-d H:i:s', time() - $days[ $rg ] * DAY_IN_SECONDS );
		}
		$q = sanitize_text_field( (string) $r->get_param( 'search' ) );
		if ( '' !== $q ) {
			$like = '%' . $wpdb->esc_like( $q ) . '%';
			$w[]  = '(r.reference LIKE %s OR c.name LIKE %s OR o.order_number LIKE %s OR o.item LIKE %s)';
			array_push( $a, $like, $like, $like, $like );
		}
		$per  = min( 200, max( 1, (int) $r->get_param( 'per_page' ) ? (int) $r->get_param( 'per_page' ) : 10 ) );
		$page = max( 1, (int) $r->get_param( 'page' ) );
		$from = ' FROM ' . RFAI_DB::t( 'requests' ) . ' r JOIN ' . RFAI_DB::t( 'orders' ) . ' o ON o.id = r.order_id JOIN ' . RFAI_DB::t( 'customers' ) . ' c ON c.id = r.customer_id WHERE ' . implode( ' AND ', $w );

		$cq    = 'SELECT COUNT(*)' . $from;
		$total = (int) $wpdb->get_var( $a ? $wpdb->prepare( $cq, $a ) : $cq ); // phpcs:ignore WordPress.DB
		$rows  = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT r.*, c.name AS customer_name, c.email AS customer_email, o.order_number, o.item' . $from . ' ORDER BY r.created_at DESC, r.id DESC LIMIT %d OFFSET %d', // phpcs:ignore WordPress.DB
				array_merge( $a, array( $per, ( $page - 1 ) * $per ) )
			)
		);
		return array( 'items' => array_map( array( __CLASS__, 'fmt' ), $rows ), 'total' => $total, 'page' => $page, 'per_page' => $per );
	}

	public static function request( WP_REST_Request $r ) {
		global $wpdb;
		$row = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT r.*, c.name AS customer_name, c.email AS customer_email, o.order_number, o.item FROM ' . RFAI_DB::t( 'requests' ) . ' r JOIN ' . RFAI_DB::t( 'orders' ) . ' o ON o.id = r.order_id JOIN ' . RFAI_DB::t( 'customers' ) . ' c ON c.id = r.customer_id WHERE r.id = %d',
				(int) $r['id']
			)
		);
		if ( ! $row ) {
			return new WP_Error( 'rfai_not_found', 'Request not found.', array( 'status' => 404 ) );
		}
		$ev  = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . RFAI_DB::t( 'audit' ) . ' WHERE request_id = %d ORDER BY created_at ASC, id ASC', $row->id ) );
		$out = self::fmt( $row );
		$out['events'] = array_map(
			function ( $e ) {
				$m = json_decode( (string) $e->meta, true );
				return array( 'id' => (int) $e->id, 'key' => $e->event_key, 'title' => $e->title, 'detail' => $e->detail, 'meta' => is_array( $m ) ? $m : array(), 'created_at' => self::iso( $e->created_at ) );
			},
			$ev
		);
		return $out;
	}

	public static function resolve( WP_REST_Request $r ) {
		global $wpdb;
		$id   = (int) $r['id'];
		$dec  = sanitize_key( (string) $r->get_param( 'decision' ) );
		$note = mb_substr( sanitize_textarea_field( (string) $r->get_param( 'note' ) ), 0, 500 );
		if ( ! in_array( $dec, array( 'approved', 'denied' ), true ) ) {
			return new WP_Error( 'rfai_bad', 'Decision must be approved or denied.', array( 'status' => 400 ) );
		}
		$rt  = RFAI_DB::t( 'requests' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT r.*, o.order_number, o.item, c.name FROM $rt r JOIN " . RFAI_DB::t( 'orders' ) . ' o ON o.id = r.order_id JOIN ' . RFAI_DB::t( 'customers' ) . ' c ON c.id = r.customer_id WHERE r.id = %d', $id ) );
		if ( ! $row || 'escalated' !== $row->decision ) {
			return new WP_Error( 'rfai_bad', 'Only escalated requests can be resolved.', array( 'status' => 409 ) );
		}
		$user  = wp_get_current_user();
		$s     = RFAI_DB::settings();
		$reply = RFAI_Engine::template(
			array( 'decision' => $dec, 'first' => strtok( $row->name, ' ' ), 'item' => $row->item, 'order' => $row->order_number, 'amount' => (float) $row->amount, 'ref' => $row->reference, 'rule' => 'human', 'window' => (int) $s['window_days'] )
		);
		if ( 'denied' === $dec ) {
			$reply = 'Hi ' . strtok( $row->name, ' ' ) . ', thanks for your patience. After a manual review of order ' . $row->order_number . ' we’re unable to approve a refund. Reply with your reference ' . $row->reference . ' if you’d like to discuss this further.';
		}
		$wpdb->update(
			$rt,
			array( 'decision' => $dec, 'human_reviewed' => 1, 'resolved_by' => $user->ID, 'resolved_note' => $note, 'resolved_at' => gmdate( 'Y-m-d H:i:s' ), 'customer_reply' => $reply ),
			array( 'id' => $id )
		);
		$wpdb->update( RFAI_DB::t( 'orders' ), array( 'refund_status' => 'approved' === $dec ? 'refunded' : 'none' ), array( 'order_number' => $row->order_number ) );
		RFAI_Engine::add_event( $id, 'human', 'Human review: ' . $dec, ( $note ? $note : 'No note provided.' ) . ' — reviewed by ' . $user->display_name . '.', array( 'reviewer' => $user->display_name, 'decision' => $dec ) );
		$req = new WP_REST_Request( 'GET' );
		$req->set_param( 'id', $id );
		return self::request( $req );
	}

	public static function customers() {
		global $wpdb;
		$o = RFAI_DB::t( 'orders' );
		$r = RFAI_DB::t( 'requests' );
		$c = RFAI_DB::t( 'customers' );
		$rows = $wpdb->get_results( "SELECT c.*, (SELECT COUNT(*) FROM $o WHERE customer_id = c.id) AS orders, (SELECT COALESCE(SUM(amount),0) FROM $o WHERE customer_id = c.id) AS spend, (SELECT COUNT(*) FROM $r WHERE customer_id = c.id) AS requests FROM $c c ORDER BY c.id" );
		return array_map(
			function ( $x ) {
				return array( 'id' => (int) $x->id, 'name' => $x->name, 'email' => $x->email, 'tier' => $x->tier, 'prior_refunds' => (int) $x->prior_refunds, 'orders' => (int) $x->orders, 'spend' => (float) $x->spend, 'requests' => (int) $x->requests, 'joined' => self::iso( $x->created_at ) );
			},
			$rows
		);
	}

	public static function orders() {
		global $wpdb;
		$o = RFAI_DB::t( 'orders' );
		$r = RFAI_DB::t( 'requests' );
		$c = RFAI_DB::t( 'customers' );
		$rows = $wpdb->get_results( "SELECT o.*, c.name AS customer_name, (SELECT decision FROM $r WHERE order_id = o.id ORDER BY id DESC LIMIT 1) AS last_decision FROM $o o JOIN $c c ON c.id = o.customer_id ORDER BY o.order_number DESC" );
		return array_map(
			function ( $x ) {
				return array( 'order_number' => $x->order_number, 'customer' => $x->customer_name, 'item' => $x->item, 'amount' => (float) $x->amount, 'ordered_at' => self::iso( $x->ordered_at ), 'final_sale' => (bool) $x->final_sale, 'refund_status' => $x->refund_status, 'last_decision' => $x->last_decision );
			},
			$rows
		);
	}

	public static function policy() {
		$s = RFAI_DB::settings();
		return array( 'name' => 'Standard Refund Policy', 'version' => $s['policy_version'], 'updated' => $s['policy_updated'] ? gmdate( 'Y-m-d\TH:i:s\Z', (int) $s['policy_updated'] ) : null, 'rules' => RFAI_Policy::rules() );
	}

	private static function public_settings() {
		$s   = RFAI_DB::settings();
		$key = RFAI_Gemini::api_key();
		return array(
			'has_key'     => '' !== $key,
			'key_hint'    => '' !== $key ? '••••' . substr( $key, -4 ) : '',
			'key_locked'  => defined( 'RFAI_GEMINI_API_KEY' ) && RFAI_GEMINI_API_KEY,
			'model'       => $s['model'],
			'ai_enabled'  => (bool) $s['ai_enabled'],
			'window_days' => (int) $s['window_days'],
			'high_value'  => (float) $s['high_value'],
			'rate_limit'  => (int) $s['rate_limit'],
			'demo_hints'  => (bool) $s['demo_hints'],
			'version'     => $s['policy_version'],
		);
	}

	public static function get_settings() {
		return self::public_settings();
	}

	public static function save_settings( WP_REST_Request $r ) {
		$p   = (array) $r->get_json_params();
		$cur = RFAI_DB::settings();
		$new = array();
		if ( isset( $p['api_key'] ) && is_string( $p['api_key'] ) && '' !== trim( $p['api_key'] ) ) {
			$new['api_key'] = sanitize_text_field( trim( $p['api_key'] ) );
		}
		if ( ! empty( $p['clear_key'] ) ) {
			$new['api_key'] = '';
		}
		if ( isset( $p['model'] ) ) {
			$m = preg_replace( '/[^a-zA-Z0-9\.\-_]/', '', (string) $p['model'] );
			if ( $m ) {
				$new['model'] = $m;
			}
		}
		$new['ai_enabled'] = empty( $p['ai_enabled'] ) ? 0 : 1;
		$new['demo_hints'] = empty( $p['demo_hints'] ) ? 0 : 1;
		$w  = isset( $p['window_days'] ) ? max( 1, min( 365, (int) $p['window_days'] ) ) : (int) $cur['window_days'];
		$hv = isset( $p['high_value'] ) ? max( 1, min( 1000000, (float) $p['high_value'] ) ) : (float) $cur['high_value'];
		$new['window_days'] = $w;
		$new['high_value']  = $hv;
		$new['rate_limit']  = isset( $p['rate_limit'] ) ? max( 1, min( 500, (int) $p['rate_limit'] ) ) : (int) $cur['rate_limit'];
		if ( $w !== (int) $cur['window_days'] || abs( $hv - (float) $cur['high_value'] ) > 0.001 ) {
			$v                     = explode( '.', (string) $cur['policy_version'] );
			$new['policy_version'] = ( (int) $v[0] ) . '.' . ( ( isset( $v[1] ) ? (int) $v[1] : 0 ) + 1 );
			$new['policy_updated'] = time();
		}
		RFAI_DB::update_settings( $new );
		return self::public_settings();
	}

	public static function test_ai() {
		$r = RFAI_Gemini::generate( 'You are a health check. Reply with the single word OK.', 'Ping', null, 256 );
		if ( ! $r['ok'] ) {
			return new WP_REST_Response( array( 'ok' => false, 'message' => $r['error'] ), 200 );
		}
		return array( 'ok' => true, 'message' => 'Connected to Gemini (' . RFAI_DB::settings()['model'] . ').' );
	}

	public static function reseed() {
		RFAI_DB::seed();
		return array( 'ok' => true );
	}
}
