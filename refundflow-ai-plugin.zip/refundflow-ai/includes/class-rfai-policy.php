<?php
defined( 'ABSPATH' ) || exit;

/**
 * Deterministic refund policy. The AI never decides; it only supplies context
 * (category, confidence, conflicts). Outcomes come from these rules, in order.
 */
class RFAI_Policy {

	public static function rules() {
		$s = RFAI_DB::settings();
		return array(
			array( 'id' => 'final_sale', 'no' => '01', 'title' => 'Final sale', 'desc' => 'Final sale items are not eligible for refunds.', 'type' => 'Eligibility rule' ),
			array( 'id' => 'window', 'no' => '02', 'title' => 'Refund window', 'desc' => 'Orders older than ' . (int) $s['window_days'] . ' days are not eligible.', 'type' => 'Eligibility rule' ),
			array( 'id' => 'high_value', 'no' => '03', 'title' => 'High value refunds', 'desc' => 'Refunds above $' . number_format( (float) $s['high_value'], 0 ) . ' require human review.', 'type' => 'Escalation rule' ),
			array( 'id' => 'damaged', 'no' => '04', 'title' => 'Damaged items', 'desc' => 'Damaged items may qualify for approval.', 'type' => 'Eligibility rule' ),
			array( 'id' => 'incorrect', 'no' => '05', 'title' => 'Incorrect items', 'desc' => 'Incorrect items may qualify for approval.', 'type' => 'Eligibility rule' ),
			array( 'id' => 'suspicious', 'no' => '06', 'title' => 'Suspicious requests', 'desc' => 'Conflicting or suspicious requests must be escalated.', 'type' => 'Escalation rule' ),
		);
	}

	public static function label( $id ) {
		$m = array(
			'final_sale'        => 'Final sale',
			'window'            => 'Outside refund window',
			'already_refunded'  => 'Already refunded',
			'high_value'        => 'High value',
			'suspicious'        => 'Suspicious / conflicting',
			'damaged'           => 'Damaged item',
			'incorrect'         => 'Incorrect item',
			'no_eligible_reason' => 'No eligible reason',
			'needs_review'      => 'Needs human judgment',
		);
		return isset( $m[ $id ] ) ? $m[ $id ] : (string) $id;
	}

	/**
	 * @param array $x order (object), category, confidence, flags[], now, settings.
	 * @return array decision (approved|denied|escalated), rule, reason, trace[].
	 */
	public static function evaluate( array $x ) {
		$o    = $x['order'];
		$s    = $x['settings'];
		$cat  = $x['category'];
		$conf = (float) $x['confidence'];
		$flag = $x['flags'];
		$days = (int) floor( ( $x['now'] - strtotime( $o->ordered_at . ' UTC' ) ) / DAY_IN_SECONDS );
		$win  = (int) $s['window_days'];
		$hv   = (float) $s['high_value'];
		$amt  = (float) $o->amount;

		$trace = array();
		$step  = function ( $rule, $hit, $note ) use ( &$trace ) {
			$trace[] = array( 'rule' => $rule, 'triggered' => (bool) $hit, 'note' => $note );
		};
		$done  = function ( $decision, $rule, $reason ) use ( &$trace ) {
			return array( 'decision' => $decision, 'rule' => $rule, 'reason' => $reason, 'trace' => $trace );
		};

		// 01 Final sale.
		$fs = (bool) $o->final_sale;
		$step( 'final_sale', $fs, $fs ? 'Item is marked final sale.' : 'Item is not final sale.' );
		if ( $fs ) {
			return $done( 'denied', 'final_sale', 'Item was sold as final sale and is not eligible for a refund.' );
		}

		// System check: never refund the same order twice.
		$rf = 'refunded' === $o->refund_status;
		$step( 'already_refunded', $rf, $rf ? 'Order was already refunded.' : 'No prior refund on this order.' );
		if ( $rf ) {
			return $done( 'denied', 'already_refunded', 'This order has already been refunded.' );
		}

		// 02 Refund window.
		$old = $days > $win;
		$step( 'window', $old, "Order is {$days} days old (limit {$win})." );
		if ( $old ) {
			return $done( 'denied', 'window', "Order is {$days} days old, beyond the {$win}-day refund window." );
		}

		// 03 High value.
		$big = $amt > $hv;
		$step( 'high_value', $big, sprintf( 'Amount $%s vs threshold $%s.', number_format( $amt, 2 ), number_format( $hv, 2 ) ) );
		if ( $big ) {
			return $done( 'escalated', 'high_value', sprintf( 'Refund amount $%s exceeds the $%s human-review threshold.', number_format( $amt, 2 ), number_format( $hv, 2 ) ) );
		}

		// 06 Suspicious / conflicting (evaluated before any approval).
		$sus = ! empty( $flag );
		$step( 'suspicious', $sus, $sus ? count( $flag ) . ' suspicious or conflicting signal(s).' : 'No suspicious or conflicting signals.' );
		if ( $sus ) {
			return $done( 'escalated', 'suspicious', 'Suspicious or conflicting signals: ' . implode( '; ', $flag ) . '.' );
		}

		// 04 / 05 Damaged or incorrect items.
		$step( 'damaged', 'damaged' === $cat, 'damaged' === $cat ? 'Request classified as damaged item.' : 'Not a damaged-item claim.' );
		$step( 'incorrect', 'wrong_item' === $cat, 'wrong_item' === $cat ? 'Request classified as incorrect item.' : 'Not an incorrect-item claim.' );
		if ( in_array( $cat, array( 'damaged', 'wrong_item' ), true ) ) {
			if ( $conf < 0.6 ) {
				return $done( 'escalated', 'needs_review', sprintf( 'Classification confidence (%d%%) is too low to approve automatically.', round( $conf * 100 ) ) );
			}
			$rule = 'damaged' === $cat ? 'damaged' : 'incorrect';
			return $done( 'approved', $rule, 'damaged' === $cat ? 'Damaged item within window and under the review threshold.' : 'Incorrect item within window and under the review threshold.' );
		}

		if ( 'changed_mind' === $cat ) {
			return $done( 'denied', 'no_eligible_reason', 'Change of mind is not an eligible refund reason under this policy.' );
		}

		return $done( 'escalated', 'needs_review', 'The stated reason cannot be verified automatically and needs human judgment.' );
	}
}
