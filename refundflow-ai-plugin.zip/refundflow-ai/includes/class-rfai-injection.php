<?php
defined( 'ABSPATH' ) || exit;

/**
 * First line of defence against prompt injection / policy-bypass attempts.
 * Detected attempts never change the policy outcome: they force escalation.
 */
class RFAI_Injection {

	public static function clean( $text ) {
		$t = wp_check_invalid_utf8( (string) $text, true );
		$t = wp_strip_all_tags( $t );
		$t = preg_replace( '/[\x{200B}-\x{200F}\x{202A}-\x{202E}\x{2060}\x{FEFF}]/u', '', $t );
		$t = preg_replace( '/[^\P{C}\n\t]/u', '', (string) $t );
		$t = str_replace( array( '<<<', '>>>', 'CUSTOMER_MESSAGE' ), array( '‹‹‹', '›››', 'CUSTOMER MESSAGE' ), (string) $t );
		$t = preg_replace( '/[ \t]+/', ' ', (string) $t );
		$t = preg_replace( '/\n{3,}/', "\n\n", (string) $t );
		return mb_substr( trim( (string) $t ), 0, 1500 );
	}

	private static function patterns() {
		return array(
			'/ignore\s+(all\s+|any\s+|the\s+|your\s+)?(previous|prior|above|earlier|preceding)\s+(instructions?|rules?|prompts?|policy|policies)/i' => 'attempt to override prior instructions',
			'/(disregard|forget|drop)\s+(the\s+|your\s+|all\s+)?(policy|policies|rules?|instructions?|guidelines?)/i' => 'attempt to discard policy',
			'/(override|bypass|circumvent|skip|waive)\s+(the\s+|your\s+|any\s+)?(policy|rules?|checks?|review|threshold|limit|restrictions?)/i' => 'attempt to bypass policy',
			'/(system|developer)\s+(prompt|message|instructions?|mode)/i' => 'reference to system internals',
			'/you\s+are\s+(now|no\s+longer)\b/i' => 'role reassignment attempt',
			'/\b(pretend|act|behave|roleplay)\b.{0,20}\b(as|like|to be)\b.{0,25}(manager|admin|supervisor|owner|unrestricted|different\s+ai)/i' => 'role-play or impersonation attempt',
			'/\bi\s*(am|\'m)\s+(the\s+|a\s+|an\s+|your\s+)?(store\s+)?(manager|admin(istrator)?|owner|developer|ceo|supervisor)\b/i' => 'claim of special authority',
			'/\b(approve|process|grant|issue)\s+(this|the|my|a)?\s*(refund|request|return)\s+(now|immediately|regardless|no\s+matter|anyway|without)/i' => 'demand to dictate the outcome',
			'/\b(reveal|print|show|repeat|leak)\b.{0,20}\b(prompt|instructions|rules|policy\s+text)/i' => 'attempt to extract instructions',
			'/\bjailbreak\b|\bdeveloper\s+mode\b|\bDAN\b/' => 'known jailbreak phrase',
			'/"?(decision|status|outcome)"?\s*:\s*"?approved?/i' => 'embedded decision payload',
			'/<\s*\/?\s*(system|assistant|instruction|prompt)\s*>/i' => 'fake role delimiters',
		);
	}

	/** @return string[] human-readable reasons; empty when clean. */
	public static function scan( $text ) {
		$hits = array();
		foreach ( self::patterns() as $re => $label ) {
			if ( preg_match( $re, (string) $text ) ) {
				$hits[] = $label;
			}
		}
		return array_values( array_unique( $hits ) );
	}
}
