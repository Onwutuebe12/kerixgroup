<?php
defined( 'ABSPATH' ) || exit;

/**
 * Pipeline: validate -> match order -> screen input -> AI classification ->
 * deterministic policy -> reply -> persist request + audit trail.
 */
class RFAI_Engine {

	private static function err( $code, $msg, $status ) {
		return array( 'ok' => false, 'code' => $code, 'message' => $msg, 'status' => $status );
	}

	private static function find_order( $order_no, $email ) {
		global $wpdb;
		$row = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT o.*, c.name AS customer_name, c.email AS customer_email, c.prior_refunds FROM ' . RFAI_DB::t( 'orders' ) . ' o JOIN ' . RFAI_DB::t( 'customers' ) . ' c ON c.id = o.customer_id WHERE o.order_number = %s',
				$order_no
			)
		);
		// Same answer for "no such order" and "wrong email" so orders cannot be enumerated.
		if ( ! $row || strtolower( $row->customer_email ) !== $email ) {
			return null;
		}
		return $row;
	}

	private static function norm( $in ) {
		$order = strtoupper( preg_replace( '/[^A-Za-z0-9\-]/', '', (string) ( isset( $in['order_number'] ) ? $in['order_number'] : '' ) ) );
		$email = strtolower( sanitize_email( (string) ( isset( $in['email'] ) ? $in['email'] : '' ) ) );
		return array( $order, $email );
	}

	public static function lookup( $in ) {
		list( $order_no, $email ) = self::norm( $in );
		if ( ! preg_match( '/^ORD-\d{3,6}$/', $order_no ) ) {
			return self::err( 'invalid_order', 'Please enter a valid order number, for example ORD-1042.', 400 );
		}
		if ( ! is_email( $email ) ) {
			return self::err( 'invalid_email', 'Please enter the email address used for the order.', 400 );
		}
		$row = self::find_order( $order_no, $email );
		if ( ! $row ) {
			return self::err( 'order_not_found', 'We couldn’t find that order. Check the order number and email address, then try again.', 404 );
		}
		return array(
			'ok'    => true,
			'order' => array(
				'order_number' => $row->order_number,
				'item'         => $row->item,
				'amount'       => (float) $row->amount,
				'days_ago'     => (int) floor( ( time() - strtotime( $row->ordered_at . ' UTC' ) ) / DAY_IN_SECONDS ),
				'first_name'   => strtok( $row->customer_name, ' ' ),
			),
		);
	}

	public static function process( array $in, array $opts = array() ) {
		global $wpdb;
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 90 ); // phpcs:ignore
		}
		$t0      = microtime( true );
		$seed    = ! empty( $opts['seed'] );
		$skip_ai = ! empty( $opts['skip_ai'] );
		$base    = isset( $opts['now'] ) ? (int) $opts['now'] : time();
		$tick    = 0;
		$events  = array();
		$log     = function ( $key, $title, $detail, $meta = array() ) use ( &$events, &$tick, $seed, $base ) {
			$events[] = array( 'key' => $key, 'title' => $title, 'detail' => $detail, 'meta' => $meta, 'ts' => $seed ? $base + 7 * $tick++ : time() );
		};
		$s = RFAI_DB::settings();

		list( $order_no, $email ) = self::norm( $in );
		$raw     = (string) ( isset( $in['message'] ) ? $in['message'] : '' );
		$message = RFAI_Injection::clean( $raw );
		$att     = isset( $in['attachments'] ) ? min( 5, max( 0, (int) $in['attachments'] ) ) : 0;

		if ( ! preg_match( '/^ORD-\d{3,6}$/', $order_no ) ) {
			return self::err( 'invalid_order', 'Please enter a valid order number, for example ORD-1042.', 400 );
		}
		if ( ! is_email( $email ) ) {
			return self::err( 'invalid_email', 'Please enter the email address used for the order.', 400 );
		}
		if ( mb_strlen( $message ) < 10 ) {
			return self::err( 'message_too_short', 'Please tell us a little more about what happened (at least a sentence).', 400 );
		}
		$row = self::find_order( $order_no, $email );
		if ( ! $row ) {
			return self::err( 'order_not_found', 'We couldn’t find that order. Check the order number and email address, then try again.', 404 );
		}

		$rt = RFAI_DB::t( 'requests' );

		// A request for this order is already waiting for a human: do not create noise.
		if ( ! $seed ) {
			$open = $wpdb->get_row( $wpdb->prepare( "SELECT reference FROM $rt WHERE order_id = %d AND decision = 'escalated' ORDER BY id DESC LIMIT 1", $row->id ) );
			if ( $open ) {
				return array(
					'ok'           => true,
					'duplicate'    => true,
					'decision'     => 'escalated',
					'reference'    => $open->reference,
					'order_number' => $row->order_number,
					'item'         => $row->item,
					'reply'        => 'Hi ' . strtok( $row->customer_name, ' ' ) . ', your request for order ' . $row->order_number . ' is already with our support team for review. You don’t need to submit it again. Your reference is ' . $open->reference . '.',
				);
			}
		}
		$prev_denied = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $rt WHERE order_id = %d AND decision = 'denied'", $row->id ) );

		$log( 'submitted', 'Refund request submitted', 'Customer submitted a refund request for ' . $order_no . '.', array( 'attachments' => $att ) );
		$log( 'retrieved', 'Customer and order data retrieved', 'Order information successfully matched.', array( 'customer' => $row->customer_name, 'item' => $row->item, 'amount' => (float) $row->amount, 'order' => $order_no ) );

		// Input screening.
		$scan = array_values( array_unique( array_merge( RFAI_Injection::scan( substr( $raw, 0, 5000 ) ), RFAI_Injection::scan( $message ) ) ) );
		$log( 'screening', 'Input safety screening', $scan ? 'Possible manipulation detected: ' . implode( '; ', $scan ) . '.' : 'No manipulation patterns detected.', array( 'matches' => $scan ) );

		// AI classification (falls back to keywords).
		$cls      = null;
		$ai_used  = 0;
		$ai_error = '';
		if ( ! $skip_ai && RFAI_Gemini::available() ) {
			$r = RFAI_Gemini::classify( $message, $row, $att );
			if ( $r['ok'] ) {
				$cls     = $r['data'];
				$ai_used = 1;
			} else {
				$ai_error = $r['error'];
			}
		}
		if ( ! $cls ) {
			$cls = self::heuristic( $message );
			if ( $ai_error ) {
				$log( 'ai_unavailable', 'AI analysis unavailable', 'Gemini could not be reached, so the built-in keyword classifier was used. Policy rules were not affected.', array( 'error' => $ai_error ) );
			}
		}
		$cat_label = strtoupper( $cls['category'] ) . ( 'damaged' === $cls['category'] ? '_ITEM' : '' );
		$log(
			'ai',
			$ai_used ? 'AI analysis completed' : 'Keyword analysis completed',
			'Request classified as ' . $cat_label . ' (' . round( $cls['confidence'] * 100 ) . '% confidence' . ( $ai_used ? ', Gemini' : ', keyword classifier' ) . ').',
			array( 'category' => $cls['category'], 'confidence' => $cls['confidence'], 'summary' => $cls['summary'], 'model' => $ai_used ? $s['model'] : 'keyword', 'conflicts' => $cls['conflicts'] )
		);

		// Suspicion signals.
		$flags = array();
		foreach ( $scan as $m ) {
			$flags[] = 'Manipulation attempt: ' . $m;
		}
		if ( ! $scan && ! empty( $cls['injection_detected'] ) ) {
			$flags[] = 'Manipulation attempt: flagged by AI screening';
		}
		foreach ( $cls['conflicts'] as $c ) {
			$flags[] = 'Conflict: ' . $c;
		}
		if ( preg_match_all( '/\bORD-?\s?(\d{3,6})\b/i', $message, $m ) ) {
			foreach ( array_unique( $m[1] ) as $n ) {
				if ( 'ORD-' . $n !== $order_no ) {
					$flags[] = 'Conflict: message references a different order (ORD-' . $n . ')';
				}
			}
		}
		if ( $prev_denied ) {
			$flags[] = 'Resubmitted after a previous denial on this order';
		}
		$recent = (int) $row->prior_refunds + (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $rt WHERE customer_id = %d AND decision = 'approved' AND created_at >= %s", $row->customer_id, gmdate( 'Y-m-d H:i:s', $base - 90 * DAY_IN_SECONDS ) ) );
		if ( $recent >= 3 ) {
			$flags[] = 'Customer already has ' . $recent . ' refunds in the last 90 days';
		}

		// Deterministic policy.
		$res = RFAI_Policy::evaluate( array( 'order' => $row, 'category' => $cls['category'], 'confidence' => $cls['confidence'], 'flags' => $flags, 'now' => $base, 'settings' => $s ) );
		$log( 'policy', 'Policy evaluation completed', $res['reason'], array( 'engine' => 'policy-engine · v' . $s['policy_version'], 'rule' => $res['rule'], 'trace' => $res['trace'] ) );

		$wpdb->insert(
			$rt,
			array(
				'order_id'         => $row->id,
				'customer_id'      => $row->customer_id,
				'message'          => $message,
				'category'         => $cls['category'],
				'ai_confidence'    => $cls['confidence'],
				'ai_summary'       => $cls['summary'],
				'ai_used'          => $ai_used,
				'flags'            => wp_json_encode( $flags ),
				'initial_decision' => $res['decision'],
				'decision'         => $res['decision'],
				'rule_id'          => $res['rule'],
				'reason'           => $res['reason'],
				'customer_reply'   => '',
				'amount'           => $row->amount,
				'policy_version'   => $s['policy_version'],
				'attachments'      => $att,
				'created_at'       => gmdate( 'Y-m-d H:i:s', $seed ? $base : time() ),
			)
		);
		$id  = (int) $wpdb->insert_id;
		$ref = 'RF-' . ( 1000 + $id );

		// Reply (Gemini composes it from decision facts only; template otherwise).
		$ctx   = array( 'decision' => $res['decision'], 'first' => strtok( $row->customer_name, ' ' ), 'item' => $row->item, 'order' => $order_no, 'amount' => (float) $row->amount, 'ref' => $ref, 'rule' => $res['rule'], 'window' => (int) $s['window_days'] );
		$reply = '';
		$src   = 'template';
		if ( ! $skip_ai && $ai_used && ( microtime( true ) - $t0 ) < 12 ) {
			$g = RFAI_Gemini::compose( $ctx );
			if ( ! empty( $g['ok'] ) ) {
				$reply = $g['text'];
				$src   = 'gemini';
			}
		}
		if ( '' === $reply ) {
			$reply = self::template( $ctx );
		}
		$wpdb->update( $rt, array( 'reference' => $ref, 'customer_reply' => $reply ), array( 'id' => $id ) );

		$verb = array( 'approved' => 'Refund approved automatically.', 'denied' => 'Refund denied per policy.', 'escalated' => 'Request escalated for human review.' );
		$log( 'decision', 'Decision generated', $verb[ $res['decision'] ], array( 'decision' => $res['decision'], 'reply_source' => $src ) );

		if ( 'approved' === $res['decision'] ) {
			$wpdb->update( RFAI_DB::t( 'orders' ), array( 'refund_status' => 'refunded' ), array( 'id' => $row->id ) );
		} elseif ( 'escalated' === $res['decision'] ) {
			$wpdb->update( RFAI_DB::t( 'orders' ), array( 'refund_status' => 'under_review' ), array( 'id' => $row->id ) );
		}
		foreach ( $events as $e ) {
			self::add_event( $id, $e['key'], $e['title'], $e['detail'], $e['meta'], $e['ts'] );
		}

		return array(
			'ok'           => true,
			'id'           => $id,
			'reference'    => $ref,
			'decision'     => $res['decision'],
			'reply'        => $reply,
			'amount'       => (float) $row->amount,
			'item'         => $row->item,
			'order_number' => $order_no,
		);
	}

	/**
	 * Continue the conversation after a decision. Read-only with respect to the
	 * decision: it can explain it, but RFAI_Gemini::answer() / reply_ok() block
	 * any text that contradicts it, and the caller never updates the request row.
	 */
	public static function answer_followup( $reference, $email, $question ) {
		global $wpdb;
		$ref      = strtoupper( preg_replace( '/[^A-Z0-9\-]/i', '', (string) $reference ) );
		$email    = strtolower( sanitize_email( (string) $email ) );
		$question = RFAI_Injection::clean( (string) $question );

		if ( ! preg_match( '/^RF-\d+$/', $ref ) || ! is_email( $email ) ) {
			return self::err( 'not_found', 'We couldn’t find that request.', 404 );
		}
		if ( mb_strlen( $question ) < 3 ) {
			return self::err( 'message_too_short', 'Please type your question.', 400 );
		}
		$rt  = RFAI_DB::t( 'requests' );
		$row = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT r.*, c.name AS customer_name, c.email AS customer_email, o.order_number, o.item FROM ' . $rt . ' r JOIN ' . RFAI_DB::t( 'customers' ) . ' c ON c.id = r.customer_id JOIN ' . RFAI_DB::t( 'orders' ) . ' o ON o.id = r.order_id WHERE r.reference = %s',
				$ref
			)
		);
		if ( ! $row || strtolower( $row->customer_email ) !== $email ) {
			return self::err( 'not_found', 'We couldn’t find that request. Check the reference and email address.', 404 );
		}

		$scan  = RFAI_Injection::scan( $question );
		$s     = RFAI_DB::settings();
		$ctx   = array( 'decision' => $row->decision, 'first' => strtok( $row->customer_name, ' ' ), 'item' => $row->item, 'order' => $row->order_number, 'amount' => (float) $row->amount, 'ref' => $row->reference, 'rule' => $row->rule_id, 'window' => (int) $s['window_days'] );
		$reply = '';
		$src   = 'template';
		if ( RFAI_Gemini::available() ) {
			$g = RFAI_Gemini::answer( $question, $ctx );
			if ( ! empty( $g['ok'] ) ) {
				$reply = $g['text'];
				$src   = 'gemini';
			}
		}
		if ( '' === $reply ) {
			$reply = self::followup_template( $question, $row );
		}
		self::add_event(
			(int) $row->id,
			'followup',
			'Customer follow-up question',
			$question,
			array( 'reply' => $reply, 'reply_source' => $src, 'manipulation' => $scan )
		);
		return array( 'ok' => true, 'reference' => $row->reference, 'decision' => $row->decision, 'reply' => $reply );
	}

	private static function followup_template( $question, $row ) {
		$q   = strtolower( $question );
		$s   = RFAI_DB::settings();
		$f   = strtok( $row->customer_name, ' ' );
		if ( 'escalated' === $row->decision ) {
			return "Hi {$f}, your request {$row->reference} is still with our support team for review, and I can’t change that from here. You’ll hear back within 1 business day.";
		}
		if ( preg_match( '/\bwhy\b/', $q ) ) {
			return "Hi {$f}, request {$row->reference} was " . $row->decision . ' because ' . self::public_reason( $row->rule_id, (int) $s['window_days'] ) . '.';
		}
		if ( preg_match( '/\b(when|how long|status|update)\b/', $q ) ) {
			return 'approved' === $row->decision
				? "Hi {$f}, the refund for {$row->reference} should reach your original payment method within 5 to 7 business days."
				: "Hi {$f}, request {$row->reference} was already decided: " . strtoupper( $row->decision ) . '. If you think this is a mistake, our team can take another look — just mention your reference.';
		}
		return "Hi {$f}, thanks for the message. Request {$row->reference} was " . strtoupper( $row->decision ) . '. Mention your reference if you’d like our team to take another look.';
	}

	public static function add_event( $request_id, $key, $title, $detail, $meta = array(), $ts = null ) {
		global $wpdb;
		$wpdb->insert(
			RFAI_DB::t( 'audit' ),
			array(
				'request_id' => $request_id,
				'event_key'  => $key,
				'title'      => $title,
				'detail'     => $detail,
				'meta'       => wp_json_encode( $meta ),
				'created_at' => gmdate( 'Y-m-d H:i:s', $ts ? $ts : time() ),
			)
		);
	}

	/** Offline classifier used when Gemini is off or unreachable. */
	public static function heuristic( $msg ) {
		$m    = strtolower( $msg );
		$sets = array(
			'damaged'          => array( 'damaged', 'broken', 'cracked', 'crack', 'defective', 'shattered', 'leak', 'dead pixel', 'stopped working', "doesn't work", 'does not work', 'not working', 'faulty', 'torn', 'dent', 'smashed', "won't turn on", "won't charge", 'jammed' ),
			'wrong_item'       => array( 'wrong item', 'wrong size', 'wrong colour', 'wrong color', 'wrong product', 'wrong one', 'incorrect item', 'different item', 'not what i ordered', 'received the wrong', 'sent the wrong', 'sent me the wrong' ),
			'not_as_described' => array( 'not as described', "doesn't match", 'does not match', 'misleading', 'listing said', 'advertised', 'counterfeit', 'different from the photos' ),
			'changed_mind'     => array( 'changed my mind', 'change of mind', "don't want", 'do not want', 'no longer need', "don't like", 'do not like', 'decided not to', 'found cheaper', "doesn't match my" ),
		);
		$hits = array();
		foreach ( $sets as $cat => $words ) {
			$n = 0;
			foreach ( $words as $w ) {
				if ( false !== strpos( $m, $w ) ) {
					$n++;
				}
			}
			if ( $n ) {
				$hits[ $cat ] = $n;
			}
		}
		$conflicts = array();
		if ( ! $hits ) {
			return array( 'category' => 'other', 'confidence' => 0.3, 'summary' => 'No clear refund reason detected in the message.', 'injection_detected' => false, 'conflicts' => $conflicts );
		}
		arsort( $hits );
		$top = key( $hits );
		if ( isset( $hits['changed_mind'] ) && ( isset( $hits['damaged'] ) || isset( $hits['wrong_item'] ) ) ) {
			$conflicts[] = 'message combines a defect claim with a change-of-mind reason';
		}
		return array(
			'category'           => $top,
			'confidence'         => round( min( 0.9, 0.55 + 0.15 * $hits[ $top ] ), 2 ),
			'summary'            => 'Customer appears to report: ' . str_replace( '_', ' ', $top ) . ' (keyword match).',
			'injection_detected' => false,
			'conflicts'          => $conflicts,
		);
	}

	public static function public_reason( $rule, $window ) {
		$m = array(
			'final_sale'         => 'the item was sold as final sale, which is not eligible for refunds',
			'window'             => "the order is outside our {$window}-day refund window",
			'already_refunded'   => 'this order has already been refunded',
			'no_eligible_reason' => 'a change of mind is not covered by our refund policy',
			'high_value'         => 'requests of this size are reviewed by a person',
			'suspicious'         => 'the request needs a closer look by our team',
			'needs_review'       => 'the request needs a closer look by our team',
			'damaged'            => 'the item arrived damaged',
			'incorrect'          => 'the wrong item was sent',
		);
		return isset( $m[ $rule ] ) ? $m[ $rule ] : 'of our refund policy';
	}

	public static function template( array $c ) {
		$f   = $c['first'];
		$amt = '$' . number_format( $c['amount'], 2 );
		switch ( $c['decision'] ) {
			case 'approved':
				return "Hi {$f}, I'm sorry your {$c['item']} wasn't right. Your refund of {$amt} for order {$c['order']} has been approved and should reach your original payment method within 5 to 7 business days. Reference: {$c['ref']}.";
			case 'denied':
				return "Hi {$f}, thanks for getting in touch about order {$c['order']}. Unfortunately we can't refund it because " . self::public_reason( $c['rule'], $c['window'] ) . ". If you think this is a mistake, reply with your reference {$c['ref']} and our team will take another look.";
			default:
				return "Hi {$f}, thanks for the details about order {$c['order']}. I've passed your request to our support team for a manual review. You can expect an update within 1 business day. Reference: {$c['ref']}.";
		}
	}

	/** Guard: the generated reply must not contradict the final decision. */
	public static function reply_ok( $text, $decision ) {
		if ( mb_strlen( $text ) < 20 || mb_strlen( $text ) > 800 ) {
			return false;
		}
		if ( 'approved' === $decision && preg_match( '/\b(denied|unable to refund|cannot refund|can\'t refund|not eligible|escalat)/i', $text ) ) {
			return false;
		}
		if ( 'denied' === $decision && preg_match( '/\b(has been approved|is approved|we\'ve approved|refund is on its way|will be refunded)/i', $text ) ) {
			return false;
		}
		if ( 'escalated' === $decision && preg_match( '/\b(has been approved|is approved|has been denied|is denied|we\'ve approved|rejected)/i', $text ) ) {
			return false;
		}
		return true;
	}
}
