(function () {
	'use strict';
	var P = window.RFAIPortal || {};
	var root = document.getElementById('rfai-portal');
	if (!root) return;

	var $ = function (s) { return root.querySelector(s); };
	var thread = $('.rfp-thread'), form = $('.rfp-form'), msg = $('#rfp-msg'), ord = $('#rfp-ord'),
		em = $('#rfp-email'), fileIn = $('#rfp-files'), fileList = $('#rfp-files-list'),
		sendBtn = $('.rfp-send'), checkBtn = $('.rfp-check'), hp = $('#rfp-website');
	var busy = false, files = [], activeRef = null, activeDecision = null;

	var SPARK = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/></svg>';
	var ICON = {
		approved: '<path d="M20 6L9 17l-5-5"/>',
		denied: '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
		escalated: '<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>'
	};

	function url(path) { return P.root + path; }
	function money(n) { return '$' + Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
	function el(tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
	function scroll() { thread.scrollTop = thread.scrollHeight; }

	function post(path, body) {
		return fetch(url(path), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
			.then(function (r) { return r.json().then(function (j) { j._status = r.status; return j; }, function () { return { ok: false, message: 'The server returned an unexpected response (HTTP ' + r.status + '). Check the PHP error log or try again.', _status: r.status }; }); })
			.catch(function () { return { ok: false, message: 'We couldn’t reach the server. Check your connection and try again.', _status: 0 }; });
	}

	function botBubble(text, extra, kind) {
		var wrap = el('div', 'rfp-msg rfp-bot' + (kind ? ' rfp-' + kind : ''));
		wrap.appendChild(el('span', 'rfp-av', SPARK));
		var body = el('div');
		body.appendChild(el('b', null, 'RefundFlow assistant'));
		var p = el('p'); p.textContent = text; body.appendChild(p);
		if (extra) body.appendChild(extra);
		wrap.appendChild(body);
		thread.appendChild(wrap); scroll();
		return wrap;
	}
	function userBubble(text) {
		var wrap = el('div', 'rfp-msg rfp-me');
		var p = el('p'); p.textContent = text; wrap.appendChild(p);
		thread.appendChild(wrap); scroll();
	}
	function typing() {
		var w = el('div', 'rfp-msg rfp-bot');
		w.appendChild(el('span', 'rfp-av', SPARK));
		w.appendChild(el('div', 'rfp-typing', '<i></i><i></i><i></i>'));
		thread.appendChild(w); scroll();
		return w;
	}

	function resultCard(r) {
		var titles = { approved: 'Refund approved', denied: 'Refund not eligible', escalated: 'Sent for human review' };
		var third = r.decision === 'approved'
			? ['Refund', money(r.amount || 0) + ' in 5 to 7 business days']
			: r.decision === 'denied' ? ['Refund', 'Not eligible'] : ['Next step', 'Reply within 1 business day'];
		var c = el('div', 'rfp-result rfp-r-' + r.decision);
		c.innerHTML =
			'<div class="rfp-rh"><span class="rfp-pill"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">' + ICON[r.decision] + '</svg></span><b></b><code></code></div>' +
			'<dl><div><dt>Order</dt><dd class="o"></dd></div><div><dt>Item</dt><dd class="i"></dd></div><div><dt>' + third[0] + '</dt><dd class="t"></dd></div></dl>';
		c.querySelector('b').textContent = titles[r.decision] || 'Decision';
		c.querySelector('code').textContent = r.reference || '';
		c.querySelector('.o').textContent = r.order_number || '';
		c.querySelector('.i').textContent = r.item || '';
		c.querySelector('.t').textContent = third[1];
		return c;
	}

	function setBusy(b) {
		busy = b; sendBtn.disabled = b; checkBtn.disabled = b;
		root.classList.toggle('is-busy', b);
	}

	function fields() {
		return { order_number: ord.value.trim(), email: em.value.trim() };
	}

	function renderFiles() {
		fileList.innerHTML = '';
		files.forEach(function (f, i) {
			var c = el('span', 'rfp-file');
			c.appendChild(document.createTextNode(f.name.length > 26 ? f.name.slice(0, 23) + '…' : f.name));
			var x = el('button', null, '×'); x.type = 'button'; x.setAttribute('aria-label', 'Remove ' + f.name);
			x.onclick = function () { files.splice(i, 1); renderFiles(); };
			c.appendChild(x); fileList.appendChild(c);
		});
	}
	fileIn.addEventListener('change', function () {
		Array.prototype.forEach.call(fileIn.files, function (f) { if (files.length < 5) files.push({ name: f.name }); });
		fileIn.value = ''; renderFiles();
	});

	function endThread() {
		activeRef = null; activeDecision = null;
		msg.placeholder = 'Describe what happened with your order…';
	}
	ord.addEventListener('input', endThread);
	em.addEventListener('input', endThread);

	checkBtn.addEventListener('click', function () {
		if (busy) return;
		endThread();
		var f = fields();
		if (!f.order_number || !f.email) { botBubble('Enter your order number and the email used for the order, then press Check Order.', null, 'warn'); return; }
		setBusy(true);
		var t = typing();
		post('lookup', f).then(function (r) {
			t.remove(); setBusy(false);
			if (!r.ok) { botBubble(r.message || 'Something went wrong. Please try again.', null, 'error'); return; }
			var o = r.order;
			botBubble('Found it, ' + o.first_name + '. Order ' + o.order_number + ' is a ' + o.item + ' (' + money(o.amount) + '), placed ' + (o.days_ago === 0 ? 'today' : o.days_ago + ' day' + (o.days_ago === 1 ? '' : 's') + ' ago') + '. Tell me what happened and I’ll review it.');
			msg.focus();
		});
	});

	function submit(e) {
		if (e) e.preventDefault();
		if (busy) return;
		var f = fields(), text = msg.value.trim();
		if (!text) { botBubble('Describe what happened with your order first, then send it.', null, 'warn'); msg.focus(); return; }

		if (activeRef) {
			userBubble(text);
			setBusy(true);
			var tt = typing();
			post('chat', { reference: activeRef, email: f.email, question: text })
				.then(function (r) {
					tt.remove(); setBusy(false);
					if (!r.ok) { botBubble(r.message || 'Something went wrong. Please try again in a moment.', null, 'error'); return; }
					botBubble(r.reply);
					msg.value = '';
				});
			return;
		}

		if (!f.order_number || !f.email) { botBubble('I also need your order number and order email so I can find the order.', null, 'warn'); (f.order_number ? em : ord).focus(); return; }
		userBubble(text);
		setBusy(true);
		var t = typing();
		post('submit', { message: text, order_number: f.order_number, email: f.email, attachments: files.map(function (x) { return x.name; }), website: hp.value })
			.then(function (r) {
				t.remove(); setBusy(false);
				if (!r.ok) {
					var nf = r.code === 'order_not_found';
					botBubble(r.message || 'Something went wrong. Please try again in a moment.', null, nf ? 'warn' : 'error');
					return;
				}
				botBubble(r.reply, r.duplicate ? null : resultCard(r));
				if (r.ok && !r.duplicate) {
					activeRef = r.reference; activeDecision = r.decision;
					msg.placeholder = 'Ask a follow-up about this request…';
				} else if (r.duplicate) {
					activeRef = r.reference; activeDecision = 'escalated';
					msg.placeholder = 'Ask a follow-up about this request…';
				}
				msg.value = ''; files = []; renderFiles();
			});
	}
	form.addEventListener('submit', submit);
	msg.addEventListener('keydown', function (e) { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) submit(e); });

	root.querySelectorAll('.rfp-demo-list button').forEach(function (b) {
		b.addEventListener('click', function () {
			endThread();
			ord.value = b.dataset.o; em.value = b.dataset.e; msg.value = b.dataset.m; msg.focus();
		});
	});
})();
