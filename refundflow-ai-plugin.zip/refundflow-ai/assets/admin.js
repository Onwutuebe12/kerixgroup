(function () {
	'use strict';
	var C = window.RFAI || {};
	var app = document.getElementById('rfai-app');
	if (!app) return;

	/* ------------------------------------------------------------ helpers */
	var IC = {
		activity: '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
		inbox: '<polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
		users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
		box: '<path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/>',
		shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
		'shield-check': '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M9 12l2 2 4-4"/>',
		clipboard: '<path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1"/>',
		settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
		sparkle: '<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/>',
		check: '<polyline points="20 6 9 17 4 12"/>',
		x: '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
		alert: '<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
		search: '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
		bell: '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
		download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
		arrow: '<line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>',
		refresh: '<polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>',
		file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/>',
		calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
		info: '<circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>',
		chev: '<polyline points="9 18 15 12 9 6"/>',
		lock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>'
	};
	function ico(n, s) { s = s || 16; return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[n] || '') + '</svg>'; }
	function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
	function money(n) { return '$' + Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
	function initials(n) { return String(n || '?').split(/\s+/).map(function (p) { return p[0]; }).join('').slice(0, 2).toUpperCase(); }
	function ago(iso) {
		if (!iso) return '';
		var s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
		if (s < 60) return 'just now';
		if (s < 3600) return Math.floor(s / 60) + ' min ago';
		if (s < 86400) return Math.floor(s / 3600) + ' hr ago';
		if (s < 86400 * 14) return Math.floor(s / 86400) + ' d ago';
		return fdate(iso);
	}
	function fdate(iso) { return iso ? new Date(iso).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : ''; }
	function ftime(iso) { return iso ? new Date(iso).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) : ''; }
	function url(path) {
		var p = path.split('?'), base = C.root + p[0];
		return p[1] ? base + (base.indexOf('?') > -1 ? '&' : '?') + p[1] : base;
	}
	function api(path, opt) {
		opt = opt || {};
		return fetch(url(path), {
			method: opt.method || 'GET',
			headers: { 'X-WP-Nonce': C.nonce, 'Content-Type': 'application/json' },
			body: opt.body ? JSON.stringify(opt.body) : undefined,
			credentials: 'same-origin'
		}).then(function (r) {
			return r.json().catch(function () { return {}; }).then(function (j) {
				if (!r.ok) throw new Error(j.message || 'Request failed (' + r.status + ')');
				return j;
			});
		});
	}
	function toast(msg, bad) {
		var t = document.createElement('div'); t.className = 'rf-t' + (bad ? ' err' : ''); t.textContent = msg;
		document.getElementById('rf-toast').appendChild(t);
		setTimeout(function () { t.remove(); }, 3200);
	}
	function badge(d) { return '<span class="rf-badge ' + esc(d) + '"><i></i>' + esc(String(d).replace('_', ' ')) + '</span>'; }
	var REASON = { damaged: 'Damaged item', wrong_item: 'Wrong item', not_as_described: 'Not as described', changed_mind: 'Changed mind', other: 'Other' };

	function stateCard(kind, msg) {
		var m = {
			empty: ['inbox', 'No refund requests yet', 'New refund requests will appear here when customers submit them.', 'Refresh'],
			search: ['search', 'No matching requests', 'Try a different search or clear the filters.', 'Clear filters'],
			error: ['alert', 'Something went wrong.', msg || 'We couldn’t process that action. Please try again in a moment.', 'Try again']
		}[kind];
		return '<div class="rf-state ' + kind + '"><span class="rf-state-i">' + ico(m[0], 20) + '</span><b>' + m[1] + '</b><p>' + esc(m[2]) + '</p><button class="rf-btn" data-act="' + (kind === 'search' ? 'clear' : 'reload') + '">' + m[3] + '</button></div>';
	}
	function skeleton() { return '<div class="rf-card"><div class="rf-skel"><i style="width:30%"></i><i></i><i></i><i style="width:70%"></i><i></i></div></div>'; }

	/* -------------------------------------------------------------- state */
	var NAV = [['overview', 'Overview', 'activity'], ['requests', 'Refund Requests', 'inbox'], ['customers', 'Customers', 'users'], ['orders', 'Orders', 'box'], ['policy', 'Policy', 'shield-check'], ['audit', 'Audit Logs', 'clipboard'], ['settings', 'Settings', 'settings']];
	var state = { view: C.view || 'overview', req: { status: '', reason: '', range: '', search: '', page: 1 }, ovStatus: '', pending: 0, auditId: null, drawerId: null };
	var content, views = {};

	function shell() {
		app.innerHTML =
			'<aside class="rf-side"><div class="rf-brand"><span class="rf-logo">' + ico('shield-check', 18) + '</span><b>RefundFlow <i>AI</i></b></div>' +
			'<div class="rf-nav-h">WORKSPACE</div><nav>' +
			NAV.map(function (n) { return '<button class="rf-nav" data-go="' + n[0] + '">' + ico(n[2]) + '<span>' + n[1] + '</span>' + (n[0] === 'requests' ? '<span class="n" id="rf-badge" hidden></span>' : '') + '</button>'; }).join('') +
			'</nav><div class="rf-nav-h">CUSTOMER EXPERIENCE</div><nav><a class="rf-nav" href="' + esc(C.portal) + '" target="_blank" rel="noopener">' + ico('sparkle') + '<span>Refund Portal</span></a></nav>' +
			'<div class="rf-user"><span class="rf-av">' + esc(initials(C.user)) + '</span><div><b>' + esc(C.user) + '</b><small>Support admin</small></div></div></aside>' +
			'<section class="rf-main"><header class="rf-head"><div><h1 id="rf-title"></h1><p id="rf-sub"></p></div>' +
			'<div class="rf-head-r"><label class="rf-search">' + ico('search', 15) + '<input id="rf-q" type="search" placeholder="Search requests, orders…" aria-label="Search requests"></label>' +
			'<button class="rf-bell" data-act="bell" aria-label="Open escalations">' + ico('bell') + '<b id="rf-dot" hidden></b></button></div></header>' +
			'<div id="rf-content" class="rf-content"></div></section><div class="rf-veil" id="rf-veil"></div><div id="rf-drawer"></div><div id="rf-toast"></div>';
		content = document.getElementById('rf-content');
	}

	function setHead(t, s) { document.getElementById('rf-title').textContent = t; document.getElementById('rf-sub').textContent = s; }
	function setPending(n) {
		state.pending = n;
		var b = document.getElementById('rf-badge'); b.hidden = !n; b.textContent = n;
		document.getElementById('rf-dot').hidden = !n;
	}
	function refreshBadge() { return api('stats').then(function (s) { setPending(s.pending); return s; }).catch(function () {}); }

	function go(view, push) {
		state.view = view;
		app.querySelectorAll('.rf-nav[data-go]').forEach(function (b) { b.classList.toggle('on', b.dataset.go === view); });
		if (push !== false && window.history && history.replaceState) {
			history.replaceState(null, '', C.page + (view === 'overview' ? '' : '&view=' + view));
		}
		load();
	}
	function load() {
		content.innerHTML = skeleton();
		Promise.resolve().then(function () { return views[state.view](); }).catch(function (e) { content.innerHTML = '<div class="rf-card">' + stateCard('error', e.message) + '</div>'; });
	}

	/* ------------------------------------------------------- shared table */
	function tabs(cur, attr) {
		return '<div class="rf-tabs" role="tablist">' + [['', 'All'], ['approved', 'Approved'], ['denied', 'Denied'], ['escalated', 'Escalated']].map(function (t) {
			return '<button class="rf-tab' + (cur === t[0] ? ' on' : '') + '" ' + attr + '="' + t[0] + '">' + t[1] + '</button>';
		}).join('') + '</div>';
	}
	function reqTable(items) {
		return '<div class="rf-tablewrap"><table class="rf-table"><thead><tr><th>REQUEST ID</th><th>CUSTOMER</th><th>ORDER</th><th>AMOUNT</th><th>REASON</th><th>DECISION</th><th>SUBMITTED</th><th>ACTION</th></tr></thead><tbody>' +
			items.map(function (r) {
				return '<tr class="click" data-open="' + r.id + '"><td class="rf-id">' + esc(r.reference) + '</td>' +
					'<td><span class="rf-cust"><span class="rf-av">' + esc(initials(r.customer.name)) + '</span>' + esc(r.customer.name) + '</span></td>' +
					'<td class="rf-muted">' + esc(r.order_number) + '</td><td class="rf-strong">' + money(r.amount) + '</td>' +
					'<td>' + esc(REASON[r.category] || r.category) + '</td><td>' + badge(r.decision) + (r.human_reviewed ? ' <span class="rf-muted" title="Resolved by a human">' + ico('users', 12) + '</span>' : '') + '</td>' +
					'<td class="rf-muted">' + esc(ago(r.created_at)) + '</td><td><button class="rf-link" data-open="' + r.id + '">View ' + ico('chev', 13) + '</button></td></tr>';
			}).join('') + '</tbody></table></div>';
	}

	/* -------------------------------------------------------------- views */
	views.overview = function () {
		setHead('Good ' + (new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 18 ? 'afternoon' : 'evening') + ', ' + (C.user || '').split(' ')[0], 'Here’s what’s happening with refund requests.');
		return api('stats').then(function (st) {
			setPending(st.pending);
			function delta(d) { return d === null ? 'New' : (d >= 0 ? '+' : '−') + Math.abs(d) + '%'; }
			function card(label, k, icon, tone) {
				var s = st[k];
				return '<div class="rf-stat"><div class="rf-stat-t"><span>' + label + '</span><span class="rf-ico ' + tone + '">' + ico(icon) + '</span></div><div class="rf-stat-v">' + s.value + '</div><div class="rf-delta' + (s.delta !== null && s.delta < 0 ? ' neg' : '') + '">' + delta(s.delta) + ' <span>vs. last week</span></div></div>';
			}
			content.innerHTML =
				'<div class="rf-stats">' + card('Total Requests', 'total', 'inbox', 'blue') + card('Approved', 'approved', 'check', 'green') + card('Denied', 'denied', 'x', 'red') + card('Escalated', 'escalated', 'alert', 'amber') + '</div>' +
				'<div class="rf-insight"><span class="rf-ico">' + ico('sparkle') + '</span><p><b>AI review insight</b><br>' + esc(st.insight) + '</p><button class="rf-link" data-go="policy">Review policy ' + ico('arrow', 13) + '</button></div>' +
				'<div class="rf-card"><div class="rf-card-h"><div><h2>Recent Refund Requests</h2><p>Review and manage customer refund decisions.</p></div><button class="rf-btn" data-go="requests">View all ' + ico('arrow', 13) + '</button></div>' +
				'<div class="rf-toolbar" id="ov-tabs"></div><div id="ov-body"></div></div>';
			return loadOverviewTable();
		});
	};
	function loadOverviewTable() {
		document.getElementById('ov-tabs').innerHTML = tabs(state.ovStatus, 'data-otab');
		return api('requests?per_page=6' + (state.ovStatus ? '&status=' + state.ovStatus : '')).then(function (r) {
			document.getElementById('ov-body').innerHTML = r.items.length ? reqTable(r.items) : stateCard('empty');
		}).catch(function (e) { document.getElementById('ov-body').innerHTML = stateCard('error', e.message); });
	}

	function qs() {
		var q = state.req, p = ['per_page=10', 'page=' + q.page];
		['status', 'reason', 'range', 'search'].forEach(function (k) { if (q[k]) p.push(k + '=' + encodeURIComponent(q[k])); });
		return p.join('&');
	}
	views.requests = function () {
		setHead('Refund Requests', 'Review and resolve customer refund requests.');
		var q = state.req;
		content.innerHTML =
			'<div class="rf-sub-row"><span>Requests across all channels</span><button class="rf-btn" data-act="csv">' + ico('download', 14) + ' Export CSV</button></div>' +
			'<div class="rf-card"><div class="rf-card-h"><div><h2>Requests</h2><p>Review and manage customer refund decisions.</p></div></div>' +
			'<div class="rf-toolbar">' + tabs(q.status, 'data-tab') + '<div class="rf-filters">' +
			'<select id="f-range" aria-label="Date"><option value="">All time</option><option value="7d"' + (q.range === '7d' ? ' selected' : '') + '>Last 7 days</option><option value="30d"' + (q.range === '30d' ? ' selected' : '') + '>Last 30 days</option></select>' +
			'<select id="f-reason" aria-label="Refund reason"><option value="">All reasons</option>' + Object.keys(REASON).map(function (k) { return '<option value="' + k + '"' + (q.reason === k ? ' selected' : '') + '>' + REASON[k] + '</option>'; }).join('') + '</select></div></div>' +
			'<div id="rq-body">' + skeleton() + '</div></div>';
		if (q.search) document.getElementById('rf-q').value = q.search;
		return loadRequests();
	};
	function loadRequests() {
		return api('requests?' + qs()).then(function (r) {
			var q = state.req, body = document.getElementById('rq-body');
			if (!body) return;
			if (!r.items.length) { body.innerHTML = stateCard(q.status || q.reason || q.range || q.search ? 'search' : 'empty'); return; }
			var pages = Math.max(1, Math.ceil(r.total / r.per_page)), from = Math.max(1, Math.min(q.page - 2, pages - 4)), nums = '';
			for (var i = from; i <= Math.min(pages, from + 4); i++) nums += '<button class="rf-pg' + (i === q.page ? ' on' : '') + '" data-page="' + i + '">' + i + '</button>';
			body.innerHTML = reqTable(r.items) + '<div class="rf-foot"><span><b class="rf-strong">' + r.total + '</b> request' + (r.total === 1 ? '' : 's') + '</span><div class="rf-pages"><button class="rf-pg b" data-page="' + (q.page - 1) + '"' + (q.page <= 1 ? ' disabled' : '') + '>Previous</button>' + nums + '<button class="rf-pg b" data-page="' + (q.page + 1) + '"' + (q.page >= pages ? ' disabled' : '') + '>Next</button></div></div>';
		}).catch(function (e) { var b = document.getElementById('rq-body'); if (b) b.innerHTML = stateCard('error', e.message); });
	}
	function exportCsv() {
		var q = state.req, p = ['per_page=200'];
		['status', 'reason', 'range', 'search'].forEach(function (k) { if (q[k]) p.push(k + '=' + encodeURIComponent(q[k])); });
		api('requests?' + p.join('&')).then(function (r) {
			var rows = [['Reference', 'Submitted (UTC)', 'Customer', 'Email', 'Order', 'Item', 'Amount', 'Reason', 'Decision', 'Rule', 'Human reviewed']].concat(r.items.map(function (x) {
				return [x.reference, x.created_at, x.customer.name, x.customer.email, x.order_number, x.item, x.amount.toFixed(2), REASON[x.category] || x.category, x.decision, x.rule_label, x.human_reviewed ? 'yes' : 'no'];
			}));
			var csv = rows.map(function (r) { return r.map(function (c) { c = String(c == null ? '' : c); if (/^[=+\-@]/.test(c)) c = "'" + c; return '"' + c.replace(/"/g, '""') + '"'; }).join(','); }).join('\n');
			download('refund-requests.csv', 'text/csv', csv); toast('Exported ' + r.items.length + ' requests');
		}).catch(function (e) { toast(e.message, true); });
	}
	function download(name, type, data) {
		var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([data], { type: type })); a.download = name; document.body.appendChild(a); a.click(); a.remove();
	}

	views.customers = function () {
		setHead('Customers', 'Customer profiles in the mock CRM.');
		return api('customers').then(function (rows) {
			content.innerHTML = '<div class="rf-card"><div class="rf-card-h"><div><h2>Customer profiles</h2><p>' + rows.length + ' customers with order history and refund activity.</p></div></div><div class="rf-tablewrap" style="margin-top:14px"><table class="rf-table"><thead><tr><th>CUSTOMER</th><th>EMAIL</th><th>TIER</th><th>ORDERS</th><th>LIFETIME SPEND</th><th>REFUNDS (90D)</th><th>REQUESTS</th><th>JOINED</th></tr></thead><tbody>' +
				rows.map(function (c) { return '<tr><td><span class="rf-cust"><span class="rf-av">' + esc(initials(c.name)) + '</span>' + esc(c.name) + '</span></td><td class="rf-muted">' + esc(c.email) + '</td><td>' + badge(c.tier) + '</td><td>' + c.orders + '</td><td class="rf-strong">' + money(c.spend) + '</td><td>' + (c.prior_refunds >= 3 ? '<span class="rf-badge escalated"><i></i>' + c.prior_refunds + '</span>' : c.prior_refunds) + '</td><td>' + c.requests + '</td><td class="rf-muted">' + esc(fdate(c.joined)) + '</td></tr>'; }).join('') + '</tbody></table></div></div>';
		});
	};
	views.orders = function () {
		setHead('Orders', 'Every order the policy engine can evaluate.');
		return api('orders').then(function (rows) {
			content.innerHTML = '<div class="rf-card"><div class="rf-card-h"><div><h2>Order history</h2><p>' + rows.length + ' orders. Use these numbers to test the customer portal.</p></div></div><div class="rf-tablewrap" style="margin-top:14px"><table class="rf-table"><thead><tr><th>ORDER</th><th>CUSTOMER</th><th>ITEM</th><th>AMOUNT</th><th>PLACED</th><th>TERMS</th><th>REFUND STATUS</th><th>LAST DECISION</th></tr></thead><tbody>' +
				rows.map(function (o) { return '<tr><td class="rf-id">' + esc(o.order_number) + '</td><td>' + esc(o.customer) + '</td><td>' + esc(o.item) + '</td><td class="rf-strong">' + money(o.amount) + '</td><td class="rf-muted">' + esc(fdate(o.ordered_at)) + ' · ' + esc(ago(o.ordered_at).replace(' ago', '')) + '</td><td>' + (o.final_sale ? '<span class="rf-badge final"><i></i>Final sale</span>' : '<span class="rf-muted">Standard</span>') + '</td><td>' + badge(o.refund_status) + '</td><td>' + (o.last_decision ? badge(o.last_decision) : '<span class="rf-muted">—</span>') + '</td></tr>'; }).join('') + '</tbody></table></div></div>';
		});
	};

	views.policy = function () {
		setHead('Refund Policy', 'View the deterministic rules used to evaluate every request.');
		return api('policy').then(function (p) {
			var icons = { final_sale: 'shield-check', window: 'calendar', high_value: 'alert', damaged: 'check', incorrect: 'box', suspicious: 'activity' };
			var upd = p.updated ? new Date(p.updated).toLocaleDateString(undefined, { month: 'long', year: 'numeric' }) : '';
			content.innerHTML =
				'<div class="rf-card rf-active"><span class="rf-ico">' + ico('shield-check', 18) + '</span><div><h3>' + esc(p.name) + ' <span class="rf-tag">ACTIVE</span></h3><p>Policy version ' + esc(p.version) + ' · Last updated ' + esc(upd) + '</p></div><button class="rf-btn dark" data-go="settings">' + ico('settings', 14) + ' Edit parameters</button></div>' +
				'<div><h2 class="rf-h3">Policy rules</h2><p class="rf-sub-row" style="margin:2px 0 12px">Rules are evaluated in order by the policy engine. AI analysis provides context but cannot change these outcomes.</p>' +
				'<div class="rf-rules">' + p.rules.map(function (r) { var esc2 = r.type.indexOf('Escalation') === 0; return '<div class="rf-rule' + (esc2 ? ' esc' : '') + '"><span class="no">' + r.no + '</span><span class="rf-ico green">' + ico(icons[r.id] || 'shield') + '</span><h3>' + esc(r.title) + '</h3><p>' + esc(r.desc) + '</p><small>' + esc(r.type) + '</small></div>'; }).join('') + '</div></div>' +
				'<div class="rf-card"><div class="rf-card-h"><div><h2>How the AI is kept in its lane</h2><p>Safeguards against prompt injection and attempts to bypass policy.</p></div></div><div class="rf-safe">' + [
					['Decisions are deterministic', 'Gemini only classifies the message. Approved, Denied and Escalated come from the rules above.'],
					['Untrusted input is fenced', 'Customer text is stripped, length-limited and passed to Gemini as delimited data with instructions to ignore commands inside it.'],
					['Manipulation forces review', 'Pattern screening and the model’s own flag escalate a request to a human. They never approve it.'],
					['Replies cannot contradict the decision', 'The reply writer never sees the customer message, and its output is checked against the final decision.'],
					['Model output is validated', 'Categories, confidence and text from the model are checked before use. If Gemini is unavailable, a keyword classifier takes over.'],
					['Orders can’t be enumerated', 'An order number must match the customer email, and the portal is rate limited with a honeypot field.']
				].map(function (s) { return '<div><span class="rf-ico green">' + ico('check', 14) + '</span><p><b>' + s[0] + '</b><span>' + s[1] + '</span></p></div>'; }).join('') + '</div></div>' +
				'<div class="rf-note">' + ico('info', 15) + '<div><b class="rf-strong">About policy changes</b><br>Any update creates a new version. Existing requests keep the policy version used at the time of evaluation.</div></div>';
		});
	};

	var EVI = { submitted: ['file', 'green'], retrieved: ['users', 'green'], screening: ['shield', 'violet'], ai: ['sparkle', 'green'], ai_unavailable: ['alert', 'amber'], policy: ['shield-check', 'green'], human: ['users', 'blue'], followup: ['sparkle', 'blue'] };
	views.audit = function () {
		return api('requests?per_page=50').then(function (list) {
			if (!list.items.length) { setHead('Audit Trail', 'A complete record for every refund request.'); content.innerHTML = '<div class="rf-card">' + stateCard('empty') + '</div>'; return; }
			if (!state.auditId) state.auditId = list.items[0].id;
			return api('requests/' + state.auditId).then(function (r) {
				setHead('Audit Trail', 'A complete, append-only record for refund request ' + r.reference + '.');
				var opts = list.items.map(function (x) { return '<option value="' + x.id + '"' + (x.id === r.id ? ' selected' : '') + '>' + esc(x.reference) + ' · ' + esc(x.customer.name) + ' · ' + esc(x.decision) + '</option>'; }).join('');
				var tech = { reference: r.reference, decision: r.decision, initial_decision: r.initial, rule: r.rule_id, policy_version: r.policy_version, category: r.category, ai_used: r.ai_used, ai_confidence: r.ai_confidence, flags: r.flags, human_reviewed: r.human_reviewed, events: r.events.map(function (e) { return { key: e.key, at: e.created_at, meta: e.meta }; }) };
				content.innerHTML =
					'<div class="rf-sub-row"><button class="rf-back" data-open="' + r.id + '">‹ Back to ' + esc(r.reference) + '</button><div class="rf-inline"><select id="a-sel" class="rf-sel" aria-label="Choose request">' + opts + '</select><button class="rf-btn" data-act="json">' + ico('download', 14) + ' Export JSON</button></div></div>' +
					'<div class="rf-card"><div class="rf-card-h"><div style="display:flex;gap:12px;align-items:center"><span class="rf-ico blue">' + ico('clipboard') + '</span><div><h2>Request lifecycle</h2><p>All times shown in your local timezone</p></div></div>' + badge(r.decision) + '</div>' +
					'<div class="rf-tl" style="margin-top:14px">' + r.events.map(function (e) {
						var i = EVI[e.key] || (e.key === 'decision' ? (r.initial === 'approved' ? ['check', 'green'] : r.initial === 'denied' ? ['x', 'red'] : ['alert', 'amber']) : ['file', 'blue']);
						if (e.key === 'human') i = [e.meta.decision === 'approved' ? 'check' : 'x', e.meta.decision === 'approved' ? 'green' : 'red'];
						return '<div class="rf-ev"><time>' + esc(ftime(e.created_at)) + '</time><span class="ic ' + i[1] + '">' + ico(i[0], 15) + '</span><div><b>' + esc(e.title) + '</b><p>' + esc(e.detail) + '</p>' + (e.meta && e.meta.engine ? '<span class="rf-chip">' + esc(e.meta.engine) + '</span>' : '') + '</div></div>';
					}).join('') + '</div>' +
					'<details class="rf-tech"><summary>' + ico('settings', 14) + ' Technical Details</summary><pre>' + esc(JSON.stringify(tech, null, 2)) + '</pre></details></div>';
				state._audit = r;
			});
		});
	};

	views.settings = function () {
		setHead('Settings', 'Configure Gemini, policy parameters and the customer portal.');
		return api('settings').then(function (s) {
			content.innerHTML =
				'<div class="rf-card"><div class="rf-card-h"><div><h2>Gemini AI</h2><p>Used for classification and reply writing. Without a key, a keyword classifier and reply templates are used.</p></div></div><div class="rf-form">' +
				'<div class="rf-field"><label for="s-key">API key</label><input id="s-key" class="rf-in" type="password" autocomplete="off" placeholder="' + (s.has_key ? esc(s.key_hint) + (s.key_locked ? ' (set in wp-config.php)' : ' (saved)') : 'Paste your Google AI Studio key') + '"' + (s.key_locked ? ' disabled' : '') + '><small>Create one at aistudio.google.com. You can also define RFAI_GEMINI_API_KEY in wp-config.php. ' + (s.has_key && !s.key_locked ? '<button class="rf-link" data-act="clearkey">Remove saved key</button>' : '') + '</small></div>' +
				'<div class="rf-field"><label for="s-model-sel">Model</label>' + modelSelect(s.model) + '<input id="s-model" class="rf-in" style="margin-top:8px;' + (MODELS.indexOf(s.model) > -1 ? 'display:none' : '') + '" placeholder="Custom model id, e.g. gemini-3.8-flash" value="' + (MODELS.indexOf(s.model) > -1 ? '' : esc(s.model)) + '"><small>Pick a model, or choose Custom to type any model id.</small></div>' +
				'<label class="rf-check"><input id="s-ai" type="checkbox"' + (s.ai_enabled ? ' checked' : '') + '> Use Gemini for new requests</label>' +
				'<div class="rf-inline"><button class="rf-btn" data-act="test">' + ico('refresh', 14) + ' Save and test connection</button><span id="s-test"></span></div></div></div>' +
				'<div class="rf-card"><div class="rf-card-h"><div><h2>Policy parameters</h2><p>Currently policy version ' + esc(s.version) + '. Changing these creates a new version.</p></div></div><div class="rf-form"><div class="rf-two">' +
				'<div class="rf-field"><label for="s-win">Refund window (days)</label><input id="s-win" class="rf-in" type="number" min="1" max="365" value="' + s.window_days + '"></div>' +
				'<div class="rf-field"><label for="s-hv">Human review above ($)</label><input id="s-hv" class="rf-in" type="number" min="1" step="1" value="' + s.high_value + '"></div></div></div></div>' +
				'<div class="rf-card"><div class="rf-card-h"><div><h2>Customer portal</h2><p>Shortcode <code>[refundflow_portal]</code> is on the “Refund Center” page.</p></div><a class="rf-btn" href="' + esc(C.portal) + '" target="_blank" rel="noopener">Open portal ' + ico('arrow', 13) + '</a></div><div class="rf-form">' +
				'<div class="rf-field"><label for="s-rate">Requests per visitor per hour</label><input id="s-rate" class="rf-in" type="number" min="1" max="500" value="' + s.rate_limit + '" style="max-width:140px"></div>' +
				'<label class="rf-check"><input id="s-demo" type="checkbox"' + (s.demo_hints ? ' checked' : '') + '> Show “Try a test scenario” shortcuts on the portal</label></div></div>' +
				'<div class="rf-inline"><button class="rf-btn dark" data-act="save">Save changes</button><button class="rf-btn red" data-act="reseed">Reset demo data</button></div>';
		});
	};
	var MODELS = ['gemini-3.8-flash', 'gemini-3.5-flash-lite', 'gemini-2.5-flash', 'gemini-2.5-flash-lite', 'gemini-2.5-pro'];
	function modelSelect(cur) {
		var known = MODELS.indexOf(cur) > -1;
		return '<select id="s-model-sel" class="rf-in">' + MODELS.map(function (m) { return '<option value="' + m + '"' + (m === cur ? ' selected' : '') + '>' + m + (m === MODELS[0] ? ' (recommended)' : '') + '</option>'; }).join('') + '<option value="__custom"' + (known ? '' : ' selected') + '>Custom…</option></select>';
	}
	function settingsBody() {
		var v = function (id) { return document.getElementById(id); };
		return { api_key: v('s-key').value, model: v('s-model-sel').value === '__custom' ? v('s-model').value : v('s-model-sel').value, ai_enabled: v('s-ai').checked, window_days: +v('s-win').value, high_value: +v('s-hv').value, rate_limit: +v('s-rate').value, demo_hints: v('s-demo').checked };
	}

	/* ------------------------------------------------------------- drawer */
	function closeDrawer() {
		document.getElementById('rf-drawer').classList.remove('open'); document.getElementById('rf-veil').classList.remove('open'); state.drawerId = null;
	}
	function openDrawer(id) {
		state.drawerId = id;
		var d = document.getElementById('rf-drawer');
		d.innerHTML = '<div class="rf-panel"><div class="rf-ph"><h2>Loading…</h2></div><div class="rf-pb">' + skeleton() + '</div></div>';
		d.classList.add('open'); document.getElementById('rf-veil').classList.add('open');
		api('requests/' + id).then(renderDrawer).catch(function (e) { d.innerHTML = '<div class="rf-panel"><div class="rf-ph"><h2>Request</h2><button class="rf-x" data-act="close">' + ico('x') + '</button></div><div class="rf-pb">' + stateCard('error', e.message) + '</div></div>'; });
	}
	function renderDrawer(r) {
		var d = document.getElementById('rf-drawer');
		d.innerHTML = '<div class="rf-panel" role="dialog" aria-label="Request ' + esc(r.reference) + '"><div class="rf-ph"><h2>' + esc(r.reference) + '</h2>' + badge(r.decision) + '<button class="rf-x" data-act="close" aria-label="Close">' + ico('x') + '</button></div><div class="rf-pb">' +
			'<div class="rf-kv"><div><small>Customer</small><b>' + esc(r.customer.name) + '</b><br><span class="rf-muted">' + esc(r.customer.email) + '</span></div><div><small>Order</small><b>' + esc(r.order_number) + '</b><br><span class="rf-muted">' + esc(r.item) + '</span></div><div><small>Amount</small><b>' + money(r.amount) + '</b></div><div><small>Submitted</small><b>' + esc(fdate(r.created_at)) + '</b><br><span class="rf-muted">' + esc(ftime(r.created_at)) + '</span></div></div>' +
			'<div class="rf-sec"><h3>Customer message</h3><div class="rf-quote">' + esc(r.message) + '</div>' + (r.attachments ? '<p class="rf-muted" style="margin-top:6px">' + r.attachments + ' file(s) attached (names only, not analysed)</p>' : '') + '</div>' +
			'<div class="rf-sec"><h3>AI analysis · ' + (r.ai_used ? 'Gemini' : 'Keyword classifier') + '</h3><div class="rf-box"><b>' + esc(REASON[r.category] || r.category) + '</b> · ' + Math.round(r.ai_confidence * 100) + '% confidence<br>' + esc(r.ai_summary) + '</div></div>' +
			(r.flags.length ? '<div class="rf-sec"><h3>Flags</h3><div class="rf-flags">' + r.flags.map(function (f) { return '<div class="rf-flag">' + ico('alert', 14) + '<span>' + esc(f) + '</span></div>'; }).join('') + '</div></div>' : '') +
			'<div class="rf-sec"><h3>Policy decision · v' + esc(r.policy_version) + '</h3><div class="rf-box"><b>' + esc(r.rule_label) + '</b><br>' + esc(r.reason) + (r.human_reviewed ? '<br><br><b>Human review</b> by ' + esc(r.resolved_by || 'staff') + ': ' + esc(r.resolved_note || 'no note') : '') + '</div></div>' +
			'<div class="rf-sec"><h3>Reply sent to customer</h3><div class="rf-quote">' + esc(r.reply) + '</div></div>' +
			(r.decision === 'escalated' ? '<div class="rf-sec rf-review"><h3>Human review</h3><textarea id="rv-note" maxlength="500" placeholder="Add a note for the audit trail (optional)"></textarea><div class="rf-actions"><button class="rf-btn green" data-resolve="approved" data-id="' + r.id + '">' + ico('check', 14) + ' Approve refund</button><button class="rf-btn red" data-resolve="denied" data-id="' + r.id + '">' + ico('x', 14) + ' Deny</button></div></div>' : '') +
			'<div class="rf-actions"><button class="rf-btn" data-audit="' + r.id + '">' + ico('clipboard', 14) + ' View audit trail</button></div></div></div>';
	}

	/* ------------------------------------------------------------- events */
	function resolve(id, decision) {
		var note = (document.getElementById('rv-note') || {}).value || '';
		app.querySelectorAll('[data-resolve]').forEach(function (b) { b.disabled = true; });
		api('requests/' + id + '/resolve', { method: 'POST', body: { decision: decision, note: note } }).then(function (r) {
			toast(r.reference + ' ' + decision); renderDrawer(r); refreshBadge(); if (state.view !== 'audit') load();
		}).catch(function (e) { toast(e.message, true); app.querySelectorAll('[data-resolve]').forEach(function (b) { b.disabled = false; }); });
	}

	function bind() {
		app.addEventListener('click', function (e) {
			var t = e.target.closest('[data-go],[data-open],[data-act],[data-tab],[data-otab],[data-page],[data-audit],[data-resolve]');
			if (e.target.id === 'rf-veil') return closeDrawer();
			if (!t) return;
			if (t.dataset.go) { closeDrawer(); return go(t.dataset.go); }
			if (t.dataset.open) { if (state.view === 'audit') { go('requests'); } return openDrawer(+t.dataset.open); }
			if (t.dataset.audit) { state.auditId = +t.dataset.audit; closeDrawer(); return go('audit'); }
			if (t.dataset.resolve) return resolve(+t.dataset.id, t.dataset.resolve);
			if (t.hasAttribute('data-otab')) { state.ovStatus = t.dataset.otab; return loadOverviewTable(); }
			if (t.hasAttribute('data-tab')) { state.req.status = t.dataset.tab; state.req.page = 1; return views.requests(); }
			if (t.dataset.page) { state.req.page = Math.max(1, +t.dataset.page); return loadRequests(); }
			switch (t.dataset.act) {
				case 'close': closeDrawer(); break;
				case 'reload': load(); break;
				case 'clear': state.req = { status: '', reason: '', range: '', search: '', page: 1 }; document.getElementById('rf-q').value = ''; go('requests'); break;
				case 'bell': state.req = { status: 'escalated', reason: '', range: '', search: '', page: 1 }; go('requests'); break;
				case 'csv': exportCsv(); break;
				case 'json': if (state._audit) download(state._audit.reference + '-audit.json', 'application/json', JSON.stringify(state._audit, null, 2)); break;
				case 'save': api('settings', { method: 'POST', body: settingsBody() }).then(function () { toast('Settings saved'); load(); }).catch(function (x) { toast(x.message, true); }); break;
				case 'clearkey': api('settings', { method: 'POST', body: Object.assign(settingsBody(), { clear_key: true }) }).then(function () { toast('API key removed'); load(); }).catch(function (x) { toast(x.message, true); }); break;
				case 'test':
					var out = document.getElementById('s-test'); out.className = 'rf-status'; out.textContent = 'Testing…';
					api('settings', { method: 'POST', body: settingsBody() }).then(function () { return api('settings/test', { method: 'POST' }); }).then(function (r) { out.className = 'rf-status ' + (r.ok ? 'ok' : 'bad'); out.textContent = r.message; }).catch(function (x) { out.className = 'rf-status bad'; out.textContent = x.message; });
					break;
				case 'reseed':
					if (!window.confirm('Reset all customers, orders, requests and audit logs to the demo data set?')) break;
					api('reseed', { method: 'POST' }).then(function () { toast('Demo data reset'); state.auditId = null; refreshBadge(); go('overview'); }).catch(function (x) { toast(x.message, true); });
					break;
			}
		});
		app.addEventListener('change', function (e) {
			if (e.target.id === 'f-range') { state.req.range = e.target.value; state.req.page = 1; loadRequests(); }
			if (e.target.id === 'f-reason') { state.req.reason = e.target.value; state.req.page = 1; loadRequests(); }
			if (e.target.id === 's-model-sel') { var c = document.getElementById('s-model'); c.style.display = e.target.value === '__custom' ? '' : 'none'; if (e.target.value === '__custom') c.focus(); }
			if (e.target.id === 'a-sel') { state.auditId = +e.target.value; load(); }
		});
		app.addEventListener('keydown', function (e) {
			if (e.key === 'Enter' && e.target.id === 'rf-q') { state.req = { status: '', reason: '', range: '', search: e.target.value.trim(), page: 1 }; go('requests'); }
			if (e.key === 'Escape') closeDrawer();
		});
	}

	shell(); bind();
	if (!views[state.view]) state.view = 'overview';
	refreshBadge();
	go(state.view, false);
})();
