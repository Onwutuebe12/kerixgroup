<?php
/**
 * Plugin Name:       RefundFlow AI
 * Description:       AI-assisted customer support refund system. Gemini classifies requests; a deterministic policy engine decides Approved, Denied or Escalated. Includes a customer portal, a support dashboard and a full audit trail.
 * Version:           1.0.2
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            RefundFlow
 * License:           GPL-2.0-or-later
 * Text Domain:       refundflow-ai
 */

defined( 'ABSPATH' ) || exit;

define( 'RFAI_VERSION', '1.0.2' );
define( 'RFAI_FILE', __FILE__ );
define( 'RFAI_DIR', plugin_dir_path( __FILE__ ) );
define( 'RFAI_URL', plugin_dir_url( __FILE__ ) );

foreach ( array( 'db', 'policy', 'injection', 'gemini', 'engine', 'rest', 'admin', 'portal' ) as $rfai_part ) {
	require_once RFAI_DIR . 'includes/class-rfai-' . $rfai_part . '.php';
}

register_activation_hook( __FILE__, array( 'RFAI_DB', 'activate' ) );

add_action(
	'plugins_loaded',
	function () {
		RFAI_DB::maybe_upgrade();
		RFAI_REST::init();
		RFAI_Admin::init();
		RFAI_Portal::init();
	}
);

add_filter(
	'plugin_action_links_' . plugin_basename( __FILE__ ),
	function ( $links ) {
		array_unshift(
			$links,
			'<a href="' . esc_url( admin_url( 'admin.php?page=refundflow-ai&view=settings' ) ) . '">Settings</a>',
			'<a href="' . esc_url( admin_url( 'admin.php?page=refundflow-ai' ) ) . '">Dashboard</a>'
		);
		return $links;
	}
);
