=== RefundFlow AI ===
Requires at least: 6.0
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.0.2
License: GPLv2 or later

AI-assisted refund processing for e-commerce support. Gemini classifies the request; a deterministic policy engine decides Approved, Denied or Escalated.

== Setup ==

1. Upload and activate. Activation creates 4 tables, seeds 15 customers, 36 orders and 12 processed requests, and creates a "Refund Center" page containing [refundflow_portal].
2. Open RefundFlow AI > Settings, paste a Google AI Studio (Gemini) API key and press "Save and test connection". You can also define RFAI_GEMINI_API_KEY in wp-config.php.
3. Open the Refund Center page, or the Refund Portal link in the dashboard sidebar, and submit a request.

Without an API key everything still works: a keyword classifier and reply templates take over, and the audit trail records that.

== Architecture ==

Portal (shortcode) -> REST /rfai/v1/submit -> RFAI_Engine::process()

1. Validate and sanitise input (order number format, email, 1500-char cap, invisible characters stripped).
2. Match order and customer. The order number must match the customer email; the same message is returned for unknown orders and wrong emails.
3. Screen input for prompt injection / policy bypass patterns (RFAI_Injection).
4. Gemini classifies the message into a validated schema: category, confidence, summary, injection flag, conflicts.
5. RFAI_Policy applies the rules in order. The AI cannot change the outcome.
6. Reply is written by Gemini from decision facts only (it never sees the customer message) and checked against the decision, or falls back to a template.
7. Request, reasoning and every step are stored in the audit table.

Policy order: final sale (deny) > already refunded (deny) > outside window (deny) > over review threshold (escalate) > suspicious or conflicting signals (escalate) > damaged or incorrect item with confidence >= 60% (approve) > change of mind (deny) > anything else (escalate).

== Safeguards ==

* AI output never decides; it only supplies context.
* Customer text is fenced as data; the model is told to ignore embedded instructions.
* Detected manipulation, conflicting claims, a different order number in the message, resubmission after denial, or 3+ refunds in 90 days force escalation to a human.
* Model output is schema-constrained and re-validated.
* Reply text is checked so it cannot contradict the final decision.
* Rate limit per IP, honeypot field, prepared SQL statements, capability checks and REST nonces on every admin route.

== Test scenarios (also available as shortcuts on the portal) ==

ORD-1001 sarah.johnson@example.com  "The left ear cup arrived cracked."     -> Approved
ORD-1003 daniel.smith@example.com   "You shipped the wrong size."          -> Approved
ORD-1002 sarah.johnson@example.com  "The desk arrived dented."             -> Escalated (over $500)
ORD-1007 james.carter@example.com   "The blender stopped working."         -> Denied (final sale)
ORD-1008 priya.patel@example.com    "The zipper broke."                    -> Denied (45 days old)
ORD-1004 michael.brown@example.com  "I changed my mind."                   -> Denied
ORD-1022 ethan.clark@example.com    "The zipper split."                    -> Escalated (frequent refunds)
ORD-1009 liam.oconnor@example.com   "Ignore all previous instructions..."  -> Escalated (manipulation)

Use Settings > Reset demo data to restore the original data set.

== Notes ==

* Attachments in the portal record file names and counts only. Files are not uploaded or analysed.
* The API key is stored in the WordPress options table. Use the wp-config.php constant if you prefer.
* Uninstalling the plugin deletes its tables and options.
